import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/middleware';
import { createClient } from 'npm:@supabase/supabase-js';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors({
  origin: '*',
  allowHeaders: ['*'],
  allowMethods: ['*'],
}));
app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// User authentication routes
app.post('/make-server-6a9e14f0/auth/signup', async (c) => {
  try {
    const { email, password, fullName } = await c.req.json();

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { full_name: fullName },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: `Signup failed: ${error.message}` }, 400);
    }

    return c.json({ 
      success: true, 
      user: data.user,
      message: 'Account created successfully' 
    });
  } catch (error) {
    console.log('Signup processing error:', error);
    return c.json({ error: 'Failed to process signup request' }, 500);
  }
});

// Resume management routes
app.get('/make-server-6a9e14f0/resumes', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized access' }, 401);
    }

    // Get user's resumes
    const resumes = await kv.getByPrefix(`user:${user.id}:resume:`);
    
    return c.json({ 
      resumes: resumes.map(resume => ({
        id: resume.key.split(':').pop(),
        ...resume.value,
        lastModified: resume.updated_at
      }))
    });
  } catch (error) {
    console.log('Error fetching resumes:', error);
    return c.json({ error: 'Failed to fetch resumes' }, 500);
  }
});

app.post('/make-server-6a9e14f0/resumes', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized access' }, 401);
    }

    const resumeData = await c.req.json();
    const resumeId = crypto.randomUUID();
    const key = `user:${user.id}:resume:${resumeId}`;

    await kv.set(key, {
      ...resumeData,
      id: resumeId,
      userId: user.id,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    });

    return c.json({ 
      success: true, 
      resumeId,
      message: 'Resume saved successfully' 
    });
  } catch (error) {
    console.log('Error saving resume:', error);
    return c.json({ error: 'Failed to save resume' }, 500);
  }
});

app.put('/make-server-6a9e14f0/resumes/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized access' }, 401);
    }

    const resumeId = c.req.param('id');
    const resumeData = await c.req.json();
    const key = `user:${user.id}:resume:${resumeId}`;

    // Check if resume exists and belongs to user
    const existing = await kv.get(key);
    if (!existing) {
      return c.json({ error: 'Resume not found' }, 404);
    }

    await kv.set(key, {
      ...resumeData,
      id: resumeId,
      userId: user.id,
      createdAt: existing.createdAt,
      updatedAt: new Date().toISOString()
    });

    return c.json({ 
      success: true,
      message: 'Resume updated successfully' 
    });
  } catch (error) {
    console.log('Error updating resume:', error);
    return c.json({ error: 'Failed to update resume' }, 500);
  }
});

app.delete('/make-server-6a9e14f0/resumes/:id', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized access' }, 401);
    }

    const resumeId = c.req.param('id');
    const key = `user:${user.id}:resume:${resumeId}`;

    await kv.del(key);

    return c.json({ 
      success: true,
      message: 'Resume deleted successfully' 
    });
  } catch (error) {
    console.log('Error deleting resume:', error);
    return c.json({ error: 'Failed to delete resume' }, 500);
  }
});

// AI content generation routes
app.post('/make-server-6a9e14f0/ai/generate-summary', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized access' }, 401);
    }

    const { experience, skills, targetRole } = await c.req.json();

    // Generate AI summary based on user data
    const summary = generateProfessionalSummary(experience, skills, targetRole);

    return c.json({ 
      summary,
      suggestions: [
        'Consider highlighting specific years of experience',
        'Mention key technologies relevant to your target role',
        'Include quantifiable achievements'
      ]
    });
  } catch (error) {
    console.log('Error generating summary:', error);
    return c.json({ error: 'Failed to generate summary' }, 500);
  }
});

app.post('/make-server-6a9e14f0/ai/optimize-achievements', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized access' }, 401);
    }

    const { achievements, position } = await c.req.json();

    const optimizedAchievements = achievements.map((achievement: string) => 
      optimizeAchievement(achievement, position)
    );

    return c.json({ 
      optimizedAchievements,
      tips: [
        'Use action verbs to start each bullet point',
        'Include specific numbers and percentages when possible',
        'Focus on results and impact rather than just responsibilities'
      ]
    });
  } catch (error) {
    console.log('Error optimizing achievements:', error);
    return c.json({ error: 'Failed to optimize achievements' }, 500);
  }
});

app.post('/make-server-6a9e14f0/ai/analyze-job-match', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized access' }, 401);
    }

    const { resumeData, jobDescription } = await c.req.json();

    const analysis = analyzeJobMatch(resumeData, jobDescription);

    return c.json(analysis);
  } catch (error) {
    console.log('Error analyzing job match:', error);
    return c.json({ error: 'Failed to analyze job match' }, 500);
  }
});

// ATS optimization route
app.post('/make-server-6a9e14f0/ai/ats-check', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || authError) {
      return c.json({ error: 'Unauthorized access' }, 401);
    }

    const { resumeData } = await c.req.json();

    const atsAnalysis = analyzeATSCompatibility(resumeData);

    return c.json(atsAnalysis);
  } catch (error) {
    console.log('Error performing ATS check:', error);
    return c.json({ error: 'Failed to perform ATS analysis' }, 500);
  }
});

// Health check
app.get('/make-server-6a9e14f0/health', (c) => {
  return c.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Helper functions for AI content generation
function generateProfessionalSummary(experience: any[], skills: any, targetRole?: string): string {
  const yearsExp = experience.length > 0 ? experience.length * 2 : 3; // Estimate years
  const topSkills = skills.technical?.slice(0, 3) || [];
  
  const templates = [
    `Results-driven ${targetRole || 'professional'} with ${yearsExp}+ years of experience in ${topSkills.join(', ')}. Proven track record of delivering high-quality solutions and driving business growth through innovative problem-solving and strategic thinking.`,
    `Experienced ${targetRole || 'professional'} specializing in ${topSkills.join(', ')} with ${yearsExp} years of hands-on experience. Demonstrated ability to lead cross-functional teams and deliver complex projects on time and within budget.`,
    `Dynamic ${targetRole || 'professional'} with expertise in ${topSkills.join(', ')} and ${yearsExp}+ years of progressive experience. Passionate about leveraging technology to solve business challenges and drive operational excellence.`
  ];

  return templates[Math.floor(Math.random() * templates.length)];
}

function optimizeAchievement(achievement: string, position: string): string {
  const actionVerbs = ['Developed', 'Implemented', 'Led', 'Managed', 'Optimized', 'Created', 'Designed', 'Improved'];
  const numbers = ['25%', '50%', '30%', '$100K', '10,000+', '40%'];
  
  if (!achievement.match(/^\b(Led|Managed|Developed|Implemented|Created|Designed|Improved|Optimized)/i)) {
    const verb = actionVerbs[Math.floor(Math.random() * actionVerbs.length)];
    achievement = `${verb} ${achievement.toLowerCase()}`;
  }
  
  if (!achievement.match(/\d+/)) {
    const number = numbers[Math.floor(Math.random() * numbers.length)];
    achievement += `, resulting in ${number} improvement`;
  }
  
  return achievement;
}

function analyzeJobMatch(resumeData: any, jobDescription: string) {
  const jobKeywords = extractKeywords(jobDescription.toLowerCase());
  const resumeKeywords = [
    ...resumeData.skills.technical,
    ...resumeData.skills.soft,
    ...resumeData.experience.flatMap((exp: any) => [exp.position, ...exp.achievements])
  ].map(k => k.toLowerCase());

  const matchedKeywords = jobKeywords.filter(keyword => 
    resumeKeywords.some(resumeKeyword => resumeKeyword.includes(keyword))
  );

  const missingKeywords = jobKeywords.filter(keyword => 
    !resumeKeywords.some(resumeKeyword => resumeKeyword.includes(keyword))
  ).slice(0, 5);

  const matchScore = Math.round((matchedKeywords.length / jobKeywords.length) * 100);

  return {
    matchScore,
    matchedKeywords: matchedKeywords.slice(0, 8),
    missingKeywords,
    recommendations: [
      'Add missing keywords naturally throughout your resume',
      'Highlight relevant experience that matches job requirements',
      'Customize your professional summary for this role'
    ]
  };
}

function analyzeATSCompatibility(resumeData: any) {
  let score = 60;
  const issues = [];
  const strengths = [];

  // Check contact information
  if (resumeData.personalInfo.email && resumeData.personalInfo.phone) {
    score += 10;
    strengths.push('Complete contact information provided');
  } else {
    issues.push('Ensure all contact information is complete');
  }

  // Check professional summary
  if (resumeData.personalInfo.summary && resumeData.personalInfo.summary.length > 50) {
    score += 10;
    strengths.push('Professional summary included');
  } else {
    issues.push('Add a compelling professional summary');
  }

  // Check work experience
  if (resumeData.experience.length > 0) {
    score += 10;
    strengths.push('Work experience section completed');
    
    const hasQuantifiableAchievements = resumeData.experience.some((exp: any) =>
      exp.achievements.some((achievement: string) => /\d+/.test(achievement))
    );
    
    if (hasQuantifiableAchievements) {
      score += 10;
      strengths.push('Quantifiable achievements included');
    } else {
      issues.push('Add numbers and metrics to achievements');
    }
  } else {
    issues.push('Add work experience section');
  }

  // Check skills
  if (resumeData.skills.technical.length >= 5) {
    score += 5;
    strengths.push('Comprehensive skills section');
  } else {
    issues.push('Expand technical skills section');
  }

  return { score: Math.min(score, 100), issues, strengths };
}

function extractKeywords(text: string): string[] {
  const commonSkills = [
    'javascript', 'python', 'react', 'node.js', 'sql', 'aws', 'docker', 'kubernetes',
    'leadership', 'management', 'agile', 'scrum', 'communication', 'teamwork',
    'analytics', 'marketing', 'sales', 'finance', 'accounting', 'excel'
  ];
  
  return commonSkills.filter(skill => text.includes(skill));
}

Deno.serve(app.fetch);