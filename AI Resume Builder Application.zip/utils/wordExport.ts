import type { ResumeData } from '../App';

export interface WordExportOptions {
  resumeData: ResumeData;
  template: 'modern' | 'classic' | 'creative';
  onProgress?: (progress: number) => void;
}

export async function exportToWord({ resumeData, template, onProgress }: WordExportOptions): Promise<void> {
  try {
    onProgress?.(10);

    // Dynamically import the docx library
    const docxModule = await import('docx');
    const { Document, Packer, Paragraph, TextRun, AlignmentType, HeadingLevel, PageOrientation } = docxModule;

    onProgress?.(30);

    const formatDate = (dateString: string) => {
      if (!dateString) return '';
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
    };

    // Template-specific colors
    const getTemplateStyles = (template: string) => {
      switch (template) {
        case 'creative':
          return {
            primaryColor: '7C3AED', // Purple
            secondaryColor: '2563EB', // Blue
            accentColor: 'C084FC', // Light Purple
          };
        case 'classic':
          return {
            primaryColor: '111827', // Dark Gray
            secondaryColor: '374151', // Gray
            accentColor: '4B5563', // Medium Gray
          };
        default: // modern
          return {
            primaryColor: '2563EB', // Blue
            secondaryColor: '374151', // Gray
            accentColor: '1E40AF', // Dark Blue
          };
      }
    };

    const styles = getTemplateStyles(template);
    const sections: any[] = [];

    // Header with Name - Center Aligned
    sections.push(
      new Paragraph({
        alignment: AlignmentType.CENTER,
        children: [
          new TextRun({
            text: resumeData.personalInfo.fullName || 'Your Name',
            size: template === 'creative' ? 36 : 32,
            bold: true,
            color: styles.primaryColor,
          }),
        ],
        spacing: { after: 200 },
      })
    );

    // Contact Information - Center Aligned
    const contactInfo = [];
    if (resumeData.personalInfo.email) contactInfo.push(`📧 ${resumeData.personalInfo.email}`);
    if (resumeData.personalInfo.phone) contactInfo.push(`📞 ${resumeData.personalInfo.phone}`);
    if (resumeData.personalInfo.location) contactInfo.push(`📍 ${resumeData.personalInfo.location}`);
    if (resumeData.personalInfo.linkedIn) contactInfo.push(`🔗 ${resumeData.personalInfo.linkedIn}`);
    if (resumeData.personalInfo.website) contactInfo.push(`🌐 ${resumeData.personalInfo.website}`);

    if (contactInfo.length > 0) {
      sections.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: contactInfo.join(' | '),
              size: 20,
              color: styles.secondaryColor,
            }),
          ],
          spacing: { after: 300 },
        })
      );
    }

    // Professional Summary
    if (resumeData.personalInfo.summary) {
      sections.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: template === 'creative' ? 'ABOUT ME' : 'PROFESSIONAL SUMMARY',
              size: 24,
              bold: true,
              color: styles.primaryColor,
            }),
          ],
          spacing: { before: 300, after: 200 },
        }),
        new Paragraph({
          alignment: AlignmentType.JUSTIFIED,
          children: [
            new TextRun({
              text: resumeData.personalInfo.summary,
              size: 22,
              color: styles.secondaryColor,
            }),
          ],
          spacing: { after: 400, line: 360 },
        })
      );
    }

    // Experience Section
    if (resumeData.experience.length > 0) {
      sections.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: 'EXPERIENCE',
              size: 24,
              bold: true,
              color: styles.primaryColor,
            }),
          ],
          spacing: { before: 400, after: 300 },
        })
      );

      resumeData.experience.forEach((exp, index) => {
        // Job Title and Company
        sections.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: exp.position,
                size: 24,
                bold: true,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { before: index > 0 ? 300 : 0, after: 100 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: exp.company,
                size: 22,
                color: styles.primaryColor,
                bold: true,
              }),
            ],
            spacing: { after: 100 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `📅 ${formatDate(exp.startDate)} - ${exp.current ? 'Present' : formatDate(exp.endDate)}`,
                size: 20,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: 200 },
          })
        );

        // Job Description
        if (exp.description) {
          sections.push(
            new Paragraph({
              alignment: AlignmentType.JUSTIFIED,
              children: [
                new TextRun({
                  text: exp.description,
                  size: 22,
                  color: styles.secondaryColor,
                }),
              ],
              spacing: { after: 200, line: 360 },
            })
          );
        }

        // Achievements with bullet points
        if (exp.achievements.length > 0) {
          exp.achievements.filter(a => a.trim()).forEach((achievement) => {
            sections.push(
              new Paragraph({
                alignment: AlignmentType.LEFT,
                children: [
                  new TextRun({
                    text: `• ${achievement}`,
                    size: 20,
                    color: styles.secondaryColor,
                  }),
                ],
                spacing: { after: 120, line: 360 },
                indent: { left: 720, hanging: 288 }, // 0.5 inch left, 0.2 inch hanging
              })
            );
          });
        }
      });
    }

    // Projects Section
    if (resumeData.projects.length > 0) {
      sections.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: 'PROJECTS',
              size: 24,
              bold: true,
              color: styles.primaryColor,
            }),
          ],
          spacing: { before: 400, after: 300 },
        })
      );

      resumeData.projects.forEach((project, index) => {
        sections.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: project.name,
                size: 24,
                bold: true,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { before: index > 0 ? 300 : 0, after: 100 },
          })
        );

        // Project links
        const projectLinks = [];
        if (project.url) projectLinks.push('🔗 Live Demo');
        if (project.githubUrl) projectLinks.push('💻 Code');
        
        if (projectLinks.length > 0) {
          sections.push(
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: projectLinks.join(' | '),
                  size: 18,
                  color: styles.accentColor,
                }),
              ],
              spacing: { after: 100 },
            })
          );
        }

        sections.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `📅 ${formatDate(project.startDate)} - ${project.current ? 'Present' : formatDate(project.endDate)}`,
                size: 20,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: 200 },
          })
        );

        // Project Description
        if (project.description) {
          sections.push(
            new Paragraph({
              alignment: AlignmentType.JUSTIFIED,
              children: [
                new TextRun({
                  text: project.description,
                  size: 22,
                  color: styles.secondaryColor,
                }),
              ],
              spacing: { after: 200, line: 360 },
            })
          );
        }

        // Technologies
        if (project.technologies.length > 0) {
          sections.push(
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: `Technologies: ${project.technologies.filter(t => t.trim()).join(', ')}`,
                  size: 20,
                  color: styles.accentColor,
                }),
              ],
              spacing: { after: 200 },
            })
          );
        }

        // Project Achievements
        if (project.achievements.length > 0) {
          project.achievements.filter(a => a.trim()).forEach((achievement) => {
            sections.push(
              new Paragraph({
                alignment: AlignmentType.LEFT,
                children: [
                  new TextRun({
                    text: `• ${achievement}`,
                    size: 20,
                    color: styles.secondaryColor,
                  }),
                ],
                spacing: { after: 120, line: 360 },
                indent: { left: 720, hanging: 288 },
              })
            );
          });
        }
      });
    }

    // Education Section
    if (resumeData.education.length > 0) {
      sections.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: 'EDUCATION',
              size: 24,
              bold: true,
              color: styles.primaryColor,
            }),
          ],
          spacing: { before: 400, after: 300 },
        })
      );

      resumeData.education.forEach((edu, index) => {
        sections.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `${edu.degree}${edu.field ? ` in ${edu.field}` : ''}`,
                size: 24,
                bold: true,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { before: index > 0 ? 300 : 0, after: 100 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: edu.institution,
                size: 22,
                color: styles.primaryColor,
                bold: true,
              }),
            ],
            spacing: { after: 100 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `📅 ${formatDate(edu.startDate)} - ${formatDate(edu.endDate)}`,
                size: 20,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: edu.honors ? 100 : 200 },
          })
        );

        if (edu.honors) {
          sections.push(
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: edu.honors,
                  size: 20,
                  color: styles.accentColor,
                  italics: true,
                }),
              ],
              spacing: { after: 200 },
            })
          );
        }
      });
    }

    // Certifications Section
    if (resumeData.certifications.length > 0) {
      sections.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: 'CERTIFICATIONS',
              size: 24,
              bold: true,
              color: styles.primaryColor,
            }),
          ],
          spacing: { before: 400, after: 300 },
        })
      );

      resumeData.certifications.forEach((cert, index) => {
        sections.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: cert.name,
                size: 24,
                bold: true,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { before: index > 0 ? 300 : 0, after: 100 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: cert.issuer,
                size: 22,
                color: styles.primaryColor,
              }),
            ],
            spacing: { after: 100 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `🏆 ${formatDate(cert.dateObtained)}${cert.expiryDate ? ` - ${formatDate(cert.expiryDate)}` : ''}`,
                size: 20,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: cert.credentialId ? 100 : 200 },
          })
        );

        if (cert.credentialId) {
          sections.push(
            new Paragraph({
              alignment: AlignmentType.CENTER,
              children: [
                new TextRun({
                  text: `ID: ${cert.credentialId}`,
                  size: 18,
                  color: styles.accentColor,
                }),
              ],
              spacing: { after: 200 },
            })
          );
        }
      });
    }

    // Skills Section
    const hasSkills = resumeData.skills.technical.length > 0 || resumeData.skills.soft.length > 0 || resumeData.skills.languages.length > 0;
    if (hasSkills) {
      sections.push(
        new Paragraph({
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({
              text: 'SKILLS',
              size: 24,
              bold: true,
              color: styles.primaryColor,
            }),
          ],
          spacing: { before: 400, after: 300 },
        })
      );

      // Technical Skills
      if (resumeData.skills.technical.length > 0) {
        sections.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: 'Technical Skills',
                size: 22,
                bold: true,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: 200 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: resumeData.skills.technical.join(' • '),
                size: 20,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: 300, line: 360 },
          })
        );
      }

      // Soft Skills
      if (resumeData.skills.soft.length > 0) {
        sections.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: 'Core Competencies',
                size: 22,
                bold: true,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: 200 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: resumeData.skills.soft.join(' • '),
                size: 20,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: 300, line: 360 },
          })
        );
      }

      // Languages
      if (resumeData.skills.languages.length > 0) {
        sections.push(
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: 'Languages',
                size: 22,
                bold: true,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: 200 },
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: resumeData.skills.languages.join(' • '),
                size: 20,
                color: styles.secondaryColor,
              }),
            ],
            spacing: { after: 300, line: 360 },
          })
        );
      }
    }

    onProgress?.(70);

    // Create the document with proper margins to prevent content cutoff
    const doc = new Document({
      creator: 'AI Resume Builder',
      title: `${resumeData.personalInfo.fullName || 'Resume'} - ${template} Template`,
      description: 'Professional resume generated by AI Resume Builder',
      sections: [
        {
          properties: {
            page: {
              margin: {
                top: 1152, // 0.8 inch in twips
                right: 1152,
                bottom: 1152,
                left: 1152,
              },
              size: {
                orientation: PageOrientation.PORTRAIT,
              },
            },
          },
          children: sections,
        },
      ],
    });

    // Generate the document blob
    const blob = await Packer.toBlob(doc);
    
    onProgress?.(90);

    // Create download link
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    
    const timestamp = new Date().toISOString().slice(0, 10);
    const filename = `${resumeData.personalInfo.fullName || 'resume'}_${template}_${timestamp}.docx`;
    link.download = filename;
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
    
    onProgress?.(100);

  } catch (error) {
    console.error('Word export error:', error);
    throw new Error('Failed to generate Word document. Please try again.');
  }
}