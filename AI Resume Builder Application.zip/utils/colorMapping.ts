// OKLCH to Hex color mappings based on the globals.css file
export const colorMappings = {
  // Light theme colors
  'oklch(0.145 0 0)': '#242424',           // foreground, card-foreground, popover-foreground
  'oklch(1 0 0)': '#ffffff',               // popover, primary-foreground
  'oklch(0.95 0.0058 264.53)': '#f1f1f3',  // secondary
  'oklch(0.708 0 0)': '#b5b5b5',           // ring, sidebar-ring
  'oklch(0.985 0 0)': '#fafafa',           // sidebar, sidebar-primary-foreground, sidebar-accent-foreground (dark)
  'oklch(0.205 0 0)': '#353535',           // primary-foreground (dark), sidebar-accent-foreground
  'oklch(0.269 0 0)': '#454545',           // secondary (dark), muted (dark), accent (dark), input (dark), border (dark), sidebar-accent (dark), sidebar-border (dark)
  'oklch(0.439 0 0)': '#707070',           // ring (dark), sidebar-ring (dark)
  'oklch(0.922 0 0)': '#ebebeb',           // sidebar-border
  'oklch(0.97 0 0)': '#f7f7f7',            // sidebar-accent

  // Chart colors
  'oklch(0.646 0.222 41.116)': '#e67e22',  // chart-1
  'oklch(0.6 0.118 184.704)': '#3498db',   // chart-2
  'oklch(0.398 0.07 227.392)': '#34495e',  // chart-3
  'oklch(0.828 0.189 84.429)': '#f1c40f',  // chart-4
  'oklch(0.769 0.188 70.08)': '#e74c3c',   // chart-5

  // Dark theme chart colors
  'oklch(0.488 0.243 264.376)': '#8e44ad',  // chart-1 (dark), sidebar-primary (dark)
  'oklch(0.696 0.17 162.48)': '#2ecc71',    // chart-2 (dark)
  'oklch(0.627 0.265 303.9)': '#e91e63',    // chart-4 (dark)
  'oklch(0.645 0.246 16.439)': '#ff5733',   // chart-5 (dark)

  // Destructive colors
  'oklch(0.396 0.141 25.723)': '#c0392b',   // destructive (dark)
  'oklch(0.637 0.237 25.331)': '#ec7063',   // destructive-foreground (dark)
};

export function convertOklchToHex(element: HTMLElement): void {
  // Get all elements in the tree
  const walker = document.createTreeWalker(
    element,
    NodeFilter.SHOW_ELEMENT,
    null
  );

  const elementsToProcess = [element];
  let node;
  while (node = walker.nextNode()) {
    elementsToProcess.push(node as HTMLElement);
  }

  elementsToProcess.forEach(el => {
    const computedStyle = window.getComputedStyle(el);
    
    // Properties that might contain oklch colors
    const colorProperties = [
      'color',
      'backgroundColor',
      'borderColor',
      'borderTopColor',
      'borderRightColor',
      'borderBottomColor',
      'borderLeftColor',
      'outlineColor',
      'textDecorationColor',
      'boxShadow',
      'fill',
      'stroke'
    ];

    colorProperties.forEach(prop => {
      const value = computedStyle.getPropertyValue(prop);
      if (value && value.includes('oklch')) {
        // Try to find a direct mapping first
        const hexColor = findOklchMapping(value);
        if (hexColor) {
          (el as HTMLElement).style.setProperty(prop, hexColor, 'important');
        } else {
          // Fallback to computed color conversion
          try {
            const convertedColor = computeColorValue(value);
            if (convertedColor) {
              (el as HTMLElement).style.setProperty(prop, convertedColor, 'important');
            }
          } catch (error) {
            // Ultimate fallback
            applyFallbackColor(el as HTMLElement, prop);
          }
        }
      }
    });

    // Also check CSS custom properties (CSS variables)
    const style = el.style;
    for (let i = 0; i < style.length; i++) {
      const property = style[i];
      if (property.startsWith('--')) {
        const value = style.getPropertyValue(property);
        if (value && value.includes('oklch')) {
          const hexColor = findOklchMapping(value);
          if (hexColor) {
            (el as HTMLElement).style.setProperty(property, hexColor, 'important');
          }
        }
      }
    }
  });
}

function findOklchMapping(colorValue: string): string | null {
  // Extract oklch function from the color value
  const oklchMatch = colorValue.match(/oklch\([^)]+\)/);
  if (oklchMatch) {
    const oklchFunction = oklchMatch[0];
    return colorMappings[oklchFunction as keyof typeof colorMappings] || null;
  }
  return null;
}

function computeColorValue(colorValue: string): string | null {
  try {
    // Create a temporary element to compute the color
    const tempElement = document.createElement('div');
    tempElement.style.position = 'absolute';
    tempElement.style.visibility = 'hidden';
    tempElement.style.color = colorValue;
    
    document.body.appendChild(tempElement);
    const computedColor = window.getComputedStyle(tempElement).color;
    document.body.removeChild(tempElement);
    
    // Return the computed color if it's not empty and different from the original
    if (computedColor && computedColor !== colorValue && !computedColor.includes('oklch')) {
      return computedColor;
    }
  } catch (error) {
    console.warn('Color computation failed:', error);
  }
  return null;
}

function applyFallbackColor(element: HTMLElement, property: string): void {
  const fallbackColors: Record<string, string> = {
    'color': '#000000',
    'backgroundColor': '#ffffff',
    'borderColor': '#cccccc',
    'borderTopColor': '#cccccc',
    'borderRightColor': '#cccccc',
    'borderBottomColor': '#cccccc',
    'borderLeftColor': '#cccccc',
    'outlineColor': '#cccccc',
    'textDecorationColor': '#000000',
    'fill': '#000000',
    'stroke': '#000000'
  };

  const fallbackColor = fallbackColors[property];
  if (fallbackColor) {
    element.style.setProperty(property, fallbackColor, 'important');
  }
}

// Pre-process CSS styles to replace oklch functions
export function preprocessStyles(): void {
  // Create a style element with hex color replacements
  const styleElement = document.createElement('style');
  styleElement.id = 'pdf-color-overrides';
  
  let cssContent = `
    /* PDF Export Color Overrides */
    :root {
      --background: #ffffff !important;
      --foreground: #242424 !important;
      --card: #ffffff !important;
      --card-foreground: #242424 !important;
      --popover: #ffffff !important;
      --popover-foreground: #242424 !important;
      --primary: #030213 !important;
      --primary-foreground: #ffffff !important;
      --secondary: #f1f1f3 !important;
      --secondary-foreground: #030213 !important;
      --muted: #ececf0 !important;
      --muted-foreground: #717182 !important;
      --accent: #e9ebef !important;
      --accent-foreground: #030213 !important;
      --destructive: #d4183d !important;
      --destructive-foreground: #ffffff !important;
      --border: rgba(0, 0, 0, 0.1) !important;
      --ring: #b5b5b5 !important;
      --chart-1: #e67e22 !important;
      --chart-2: #3498db !important;
      --chart-3: #34495e !important;
      --chart-4: #f1c40f !important;
      --chart-5: #e74c3c !important;
    }
    
    .dark {
      --background: #242424 !important;
      --foreground: #fafafa !important;
      --card: #242424 !important;
      --card-foreground: #fafafa !important;
      --popover: #242424 !important;
      --popover-foreground: #fafafa !important;
      --primary: #fafafa !important;
      --primary-foreground: #353535 !important;
      --secondary: #454545 !important;
      --secondary-foreground: #fafafa !important;
      --muted: #454545 !important;
      --muted-foreground: #b5b5b5 !important;
      --accent: #454545 !important;
      --accent-foreground: #fafafa !important;
      --destructive: #c0392b !important;
      --destructive-foreground: #ec7063 !important;
      --border: #454545 !important;
      --ring: #707070 !important;
      --chart-1: #8e44ad !important;
      --chart-2: #2ecc71 !important;
      --chart-3: #e74c3c !important;
      --chart-4: #e91e63 !important;
      --chart-5: #ff5733 !important;
    }
    
    /* Force specific color overrides for PDF */
    [data-resume-preview] * {
      color: #000000 !important;
      background-color: transparent !important;
    }
    
    [data-resume-preview] {
      background-color: #ffffff !important;
      color: #000000 !important;
    }
    
    [data-resume-preview] .text-blue-600 {
      color: #0066cc !important;
    }
    
    [data-resume-preview] .text-purple-600 {
      color: #8b5cf6 !important;
    }
    
    [data-resume-preview] .text-gray-900 {
      color: #111827 !important;
    }
    
    [data-resume-preview] .text-gray-700 {
      color: #374151 !important;
    }
    
    [data-resume-preview] .text-gray-600 {
      color: #4b5563 !important;
    }
    
    [data-resume-preview] .bg-blue-100 {
      background-color: #dbeafe !important;
    }
    
    [data-resume-preview] .bg-purple-100 {
      background-color: #f3e8ff !important;
    }
    
    [data-resume-preview] .bg-gray-100 {
      background-color: #f3f4f6 !important;
    }
    
    [data-resume-preview] .border-blue-600 {
      border-color: #0066cc !important;
    }
    
    [data-resume-preview] .border-b {
      border-bottom-color: #e5e7eb !important;
    }
  `;
  
  styleElement.textContent = cssContent;
  document.head.appendChild(styleElement);
}

export function removePreprocessedStyles(): void {
  const styleElement = document.getElementById('pdf-color-overrides');
  if (styleElement) {
    styleElement.remove();
  }
}