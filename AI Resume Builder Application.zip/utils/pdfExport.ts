import type { ResumeData } from '../App';
import { convertOklchToHex, preprocessStyles, removePreprocessedStyles } from './colorMapping';
import { createRoot } from 'react-dom/client';
import React from 'react';
import { ResumePreview } from '../components/ResumePreview';

export interface PDFExportOptions {
  resumeData: ResumeData;
  template: 'modern' | 'classic' | 'creative';
  onProgress?: (progress: number) => void;
}

export async function exportToPDF({ resumeData, template, onProgress }: PDFExportOptions): Promise<void> {
  try {
    onProgress?.(5);

    // Preprocess styles to handle oklch colors
    preprocessStyles();

    onProgress?.(10);

    // Dynamically import PDF generation libraries
    const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([
      import('html2canvas'),
      import('jspdf')
    ]);

    onProgress?.(20);

    // Always create a fresh element for PDF export to avoid conflicts
    const previewElement = document.createElement('div');
    previewElement.setAttribute('data-resume-preview', '');
    
    // Set up container with proper sizing to prevent content cutoff
    previewElement.style.cssText = `
      position: absolute;
      left: -9999px;
      top: 0;
      width: 800px;
      max-width: 800px;
      min-width: 800px;
      background-color: #ffffff;
      color: #000000;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      padding: 0;
      box-sizing: border-box;
      overflow: visible;
      display: block;
      min-height: auto;
    `;
    
    // Add Tailwind CSS classes container for proper styling
    const tailwindContainer = document.createElement('div');
    tailwindContainer.className = 'bg-white text-black';
    tailwindContainer.style.cssText = `
      width: 100%;
      background-color: #ffffff;
      color: #000000;
      overflow: visible;
      min-height: auto;
    `;
    
    previewElement.appendChild(tailwindContainer);
    
    // Render the actual ResumePreview component
    const root = createRoot(tailwindContainer);
    root.render(React.createElement(ResumePreview, {
      data: resumeData,
      template: template,
      isPDFMode: true
    }));
    
    document.body.appendChild(previewElement);
    
    // Wait for React to render completely and layout to stabilize
    await new Promise(resolve => setTimeout(resolve, 1500));

    onProgress?.(30);

    // Wait for all images and fonts to load
    await new Promise(resolve => {
      const images = previewElement.querySelectorAll('img');
      const promises = Array.from(images).map(img => {
        if (img.complete) return Promise.resolve();
        return new Promise(resolve => {
          img.onload = resolve;
          img.onerror = resolve;
        });
      });
      
      Promise.all(promises).then(resolve);
      setTimeout(resolve, 1000); // Extended fallback timeout
    });

    onProgress?.(40);

    // Get the actual content height after rendering
    const actualHeight = Math.max(
      previewElement.scrollHeight,
      previewElement.offsetHeight,
      tailwindContainer.scrollHeight,
      tailwindContainer.offsetHeight,
      1200 // Minimum height
    );

    // Update the container height to accommodate all content
    previewElement.style.height = `${actualHeight}px`;
    tailwindContainer.style.height = `${actualHeight}px`;

    // Wait for layout to adjust to new height
    await new Promise(resolve => setTimeout(resolve, 500));

    // Convert oklch colors to hex equivalents
    try {
      convertOklchToHex(previewElement);
    } catch (error) {
      console.warn('Color conversion warning:', error);
    }

    // Additional wait for color processing and layout stabilization
    await new Promise(resolve => setTimeout(resolve, 500));

    onProgress?.(50);

    // Calculate optimal canvas dimensions
    const contentWidth = 800;
    const contentHeight = actualHeight;
    const scale = 2; // High DPI for crisp text

    // Generate canvas with optimal settings for PDF to prevent content cutoff
    const canvas = await html2canvas(previewElement, {
      scale: scale,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      width: contentWidth,
      height: contentHeight,
      scrollX: 0,
      scrollY: 0,
      logging: false,
      removeContainer: false,
      foreignObjectRendering: false,
      imageTimeout: 15000,
      windowWidth: contentWidth,
      windowHeight: contentHeight,
      ignoreElements: (element) => {
        return element.tagName === 'SCRIPT' || 
               element.tagName === 'STYLE' ||
               element.classList.contains('no-pdf');
      },
      onclone: (clonedDoc) => {
        const clonedBody = clonedDoc.body;
        clonedBody.style.margin = '0';
        clonedBody.style.padding = '0';
        clonedBody.style.backgroundColor = '#ffffff';
        clonedBody.style.color = '#000000';
        clonedBody.style.fontFamily = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        clonedBody.style.overflow = 'visible';
        clonedBody.style.height = 'auto';
        clonedBody.style.minHeight = 'auto';
        
        // Force all elements to be visible and prevent cutoff
        const allElements = clonedDoc.querySelectorAll('*');
        allElements.forEach((el: any) => {
          // Fix colors
          if (!el.style.color || el.style.color.includes('oklch')) {
            el.style.color = '#000000';
          }
          if (el.style.backgroundColor && el.style.backgroundColor.includes('oklch')) {
            el.style.backgroundColor = '#ffffff';
          }
          if (el.style.borderColor && el.style.borderColor.includes('oklch')) {
            el.style.borderColor = '#cccccc';
          }
          
          // Ensure proper text alignment is preserved
          if (el.classList.contains('text-center')) {
            el.style.textAlign = 'center';
          }
          if (el.classList.contains('text-left')) {
            el.style.textAlign = 'left';
          }
          if (el.classList.contains('text-right')) {
            el.style.textAlign = 'right';
          }
          
          // Ensure flexbox center alignment is converted properly
          if (el.classList.contains('justify-center')) {
            el.style.display = 'flex';
            el.style.justifyContent = 'center';
          }
          if (el.classList.contains('items-center')) {
            el.style.display = 'flex';
            el.style.alignItems = 'center';
          }
          if (el.classList.contains('flex')) {
            el.style.display = 'flex';
          }
          if (el.classList.contains('flex-wrap')) {
            el.style.flexWrap = 'wrap';
          }
          if (el.classList.contains('mx-auto')) {
            el.style.marginLeft = 'auto';
            el.style.marginRight = 'auto';
          }
          
          // Ensure max-width constraints are applied but don't cause cutoff
          if (el.classList.contains('max-w-4xl')) {
            el.style.maxWidth = '56rem';
            el.style.width = 'auto';
          }
          if (el.classList.contains('max-w-3xl')) {
            el.style.maxWidth = '48rem';
            el.style.width = 'auto';
          }
          
          // Prevent content cutoff with proper text wrapping
          if (el.tagName === 'P' || el.tagName === 'LI' || el.tagName === 'SPAN' || el.tagName === 'DIV') {
            el.style.wordWrap = 'break-word';
            el.style.overflowWrap = 'break-word';
            el.style.hyphens = 'auto';
            el.style.lineHeight = '1.5';
            el.style.overflow = 'visible';
            el.style.whiteSpace = 'normal';
            el.style.textOverflow = 'visible';
            el.style.maxWidth = 'none';
          }
          
          // Ensure list items display properly and don't get cut off
          if (el.tagName === 'UL' || el.tagName === 'OL') {
            el.style.pageBreakInside = 'auto';
            el.style.orphans = '1';
            el.style.widows = '1';
            el.style.overflow = 'visible';
            el.style.width = 'auto';
            el.style.maxWidth = 'none';
          }
          
          if (el.tagName === 'LI') {
            el.style.overflow = 'visible';
            el.style.wordBreak = 'break-word';
            el.style.whiteSpace = 'normal';
            el.style.width = 'auto';
            el.style.maxWidth = 'none';
          }
          
          // Prevent breaking inside experience/project items but allow overflow
          if (el.classList.contains('mb-4') || el.classList.contains('mb-6')) {
            el.style.pageBreakInside = 'auto';
            el.style.overflow = 'visible';
            el.style.height = 'auto';
            el.style.minHeight = 'auto';
          }
          
          // Ensure containers don't cut off content
          el.style.overflow = 'visible';
          el.style.height = 'auto';
          el.style.minHeight = 'auto';
          el.style.maxHeight = 'none';
          
          // Ensure spacing is properly applied
          if (el.classList.contains('space-y-6')) {
            const children = Array.from(el.children);
            children.forEach((child: any, index) => {
              if (index > 0) {
                child.style.marginTop = '1.5rem';
              }
            });
          }
          if (el.classList.contains('space-y-4')) {
            const children = Array.from(el.children);
            children.forEach((child: any, index) => {
              if (index > 0) {
                child.style.marginTop = '1rem';
              }
            });
          }
          if (el.classList.contains('gap-6')) {
            el.style.gap = '1.5rem';
          }
          if (el.classList.contains('gap-4')) {
            el.style.gap = '1rem';
          }
          if (el.classList.contains('gap-2')) {
            el.style.gap = '0.5rem';
          }
        });
        
        // Ensure the main container doesn't cut off content
        const mainContainer = clonedDoc.querySelector('[data-resume-preview]');
        if (mainContainer) {
          (mainContainer as any).style.overflow = 'visible';
          (mainContainer as any).style.height = 'auto';
          (mainContainer as any).style.minHeight = 'auto';
          (mainContainer as any).style.maxHeight = 'none';
          (mainContainer as any).style.width = '100%';
          (mainContainer as any).style.maxWidth = 'none';
        }
      }
    });

    // Clean up the temporary element
    if (previewElement.parentNode) {
      document.body.removeChild(previewElement);
    }

    onProgress?.(75);

    // Create PDF with proper dimensions to fit all content
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
      compress: true
    });

    const imgData = canvas.toDataURL('image/png', 0.95);
    const pdfWidth = 210; // A4 width in mm
    const pdfHeight = 297; // A4 height in mm
    const imgAspectRatio = canvas.width / canvas.height;
    const pdfAspectRatio = pdfWidth / pdfHeight;
    
    let imgWidth, imgHeight;
    
    // Calculate dimensions to fit content without cutting off
    if (imgAspectRatio > pdfAspectRatio) {
      // Image is wider, fit to width
      imgWidth = pdfWidth;
      imgHeight = pdfWidth / imgAspectRatio;
    } else {
      // Image is taller, fit to height or allow multiple pages
      imgWidth = pdfHeight * imgAspectRatio;
      imgHeight = pdfHeight;
    }
    
    // If content is too tall for one page, use multiple pages
    const totalPages = Math.ceil(imgHeight / pdfHeight);
    
    for (let page = 0; page < totalPages; page++) {
      if (page > 0) {
        pdf.addPage();
      }
      
      const yOffset = -(page * pdfHeight);
      pdf.addImage(
        imgData, 
        'PNG', 
        (pdfWidth - imgWidth) / 2, // Center horizontally
        yOffset, 
        imgWidth, 
        imgHeight, 
        undefined, 
        'FAST'
      );
    }

    onProgress?.(95);

    // Generate filename and download
    const timestamp = new Date().toISOString().slice(0, 10);
    const filename = `${resumeData.personalInfo.fullName || 'resume'}_${template}_${timestamp}.pdf`;
    
    pdf.save(filename);
    
    onProgress?.(100);

  } catch (error) {
    console.error('PDF export error:', error);
    throw new Error('Failed to generate PDF. Please try again.');
  } finally {
    // Clean up preprocessed styles
    removePreprocessedStyles();
  }
}