import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Input } from './ui/input';
import { Alert, AlertDescription } from './ui/alert';
import { X, FileText, Plus, Trash2, Edit, Calendar, Search } from 'lucide-react';
import { projectId } from '../utils/supabase/info';

interface Resume {
  id: string;
  personalInfo: {
    fullName: string;
    email: string;
  };
  lastModified: string;
  createdAt: string;
}

interface ResumeManagerProps {
  onClose: () => void;
  onResumeSelect: (resume: any) => void;
  accessToken: string;
}

export function ResumeManager({ onClose, onResumeSelect, accessToken }: ResumeManagerProps) {
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [filteredResumes, setFilteredResumes] = useState<Resume[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    loadResumes();
  }, []);

  useEffect(() => {
    const filtered = resumes.filter(resume =>
      resume.personalInfo.fullName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      resume.personalInfo.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredResumes(filtered);
  }, [resumes, searchTerm]);

  const loadResumes = async () => {
    setIsLoading(true);
    setError('');

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/resumes`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to load resumes');
      }

      setResumes(result.resumes || []);
    } catch (error: any) {
      setError(error.message);
      console.log('Error loading resumes:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const deleteResume = async (resumeId: string) => {
    setDeletingId(resumeId);

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/resumes/${resumeId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Failed to delete resume');
      }

      setResumes(prev => prev.filter(resume => resume.id !== resumeId));
    } catch (error: any) {
      setError(error.message);
      console.log('Error deleting resume:', error);
    } finally {
      setDeletingId(null);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const createNewResume = () => {
    onResumeSelect({
      personalInfo: {
        fullName: '',
        email: '',
        phone: '',
        location: '',
        linkedIn: '',
        website: '',
        summary: '',
      },
      experience: [],
      education: [],
      skills: {
        technical: [],
        soft: [],
        languages: [],
        certifications: [],
      },
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[80vh] overflow-hidden">
        <CardHeader className="flex flex-row items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            My Resumes
          </CardTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search and New Resume */}
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search resumes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button onClick={createNewResume} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              New Resume
            </Button>
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* Resumes List */}
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
                <p className="text-muted-foreground">Loading your resumes...</p>
              </div>
            ) : filteredResumes.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4 opacity-50" />
                <p className="text-muted-foreground mb-2">
                  {searchTerm ? 'No resumes match your search' : 'No resumes found'}
                </p>
                <p className="text-sm text-muted-foreground">
                  {searchTerm ? 'Try a different search term' : 'Create your first resume to get started'}
                </p>
              </div>
            ) : (
              filteredResumes.map((resume) => (
                <Card key={resume.id} className="border-l-4 border-l-primary/20 hover:border-l-primary/50 transition-colors">
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-medium">
                            {resume.personalInfo.fullName || 'Untitled Resume'}
                          </h3>
                          <Badge variant="outline" className="text-xs">
                            {resume.id.slice(0, 8)}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {resume.personalInfo.email}
                        </p>
                        <div className="flex items-center gap-4 text-xs text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            Created: {formatDate(resume.createdAt)}
                          </div>
                          <div className="flex items-center gap-1">
                            <Edit className="h-3 w-3" />
                            Modified: {formatDate(resume.lastModified)}
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onResumeSelect(resume)}
                        >
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteResume(resume.id)}
                          disabled={deletingId === resume.id}
                        >
                          {deletingId === resume.id ? (
                            <div className="animate-spin rounded-full h-3 w-3 border-b-2 border-current" />
                          ) : (
                            <Trash2 className="h-3 w-3" />
                          )}
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Stats */}
          {!isLoading && (
            <div className="pt-4 border-t text-center">
              <p className="text-sm text-muted-foreground">
                {resumes.length} resume{resumes.length !== 1 ? 's' : ''} total
                {filteredResumes.length !== resumes.length && (
                  <span> • {filteredResumes.length} matching search</span>
                )}
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}