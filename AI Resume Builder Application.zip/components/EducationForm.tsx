import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ArrowRight, ArrowLeft, Plus, Trash2, GraduationCap, ChevronRight, ChevronLeft } from 'lucide-react';
import type { ResumeData } from '../App';

interface EducationFormProps {
  data: ResumeData['education'];
  onChange: (data: ResumeData['education']) => void;
  onNext: () => void;
  onPrev: () => void;
}

const degreeCategories = {
  'High School': [
    'High School Diploma',
    'General Educational Development (GED)',
    'International Baccalaureate (IB)',
    'A-Levels',
    'National Senior Certificate (NSC)',
    'Senior Certificate (Matric)',
    'Independent Examinations Board (IEB)',
  ],
  'South African Qualifications': [
    'National Senior Certificate (NSC)',
    'Senior Certificate (Matric)',
    'Independent Examinations Board (IEB)',
    'National Certificate (Vocational) - NC(V)',
    'National Certificate - Level 2',
    'National Certificate - Level 3',
    'National Certificate - Level 4',
    'Higher Certificate',
    'Advanced Certificate',
    'National Diploma',
    'Diploma',
    'Advanced Diploma',
    'Bachelor of Technology (BTech)',
    'Master of Technology (MTech)',
    'Doctor of Technology (DTech)',
  ],
  'Associate Degrees': [
    'Associate of Arts (AA)',
    'Associate of Science (AS)',
    'Associate of Applied Science (AAS)',
    'Associate of Business Administration (ABA)',
    'Associate of Engineering (AE)',
    'Associate of Fine Arts (AFA)',
  ],
  "Bachelor's Degrees": [
    'Bachelor of Arts (BA)',
    'Bachelor of Science (BS)',
    'Bachelor of Business Administration (BBA)',
    'Bachelor of Engineering (BE)',
    'Bachelor of Technology (BTech)',
    'Bachelor of Computer Science (BCS)',
    'Bachelor of Fine Arts (BFA)',
    'Bachelor of Music (BM)',
    'Bachelor of Education (BEd)',
    'Bachelor of Nursing (BSN)',
    'Bachelor of Architecture (BArch)',
    'Bachelor of Social Work (BSW)',
    'Bachelor of Laws (LLB)',
    'Bachelor of Commerce (BCom)',
    'Bachelor of Applied Science (BAS)',
  ],
  "Master's Degrees": [
    'Master of Arts (MA)',
    'Master of Science (MS)',
    'Master of Business Administration (MBA)',
    'Master of Engineering (MEng)',
    'Master of Technology (MTech)',
    'Master of Computer Science (MCS)',
    'Master of Fine Arts (MFA)',
    'Master of Education (MEd)',
    'Master of Public Administration (MPA)',
    'Master of Social Work (MSW)',
    'Master of Laws (LLM)',
    'Master of Architecture (MArch)',
    'Master of Public Health (MPH)',
    'Master of Library Science (MLS)',
    'Master of Information Systems (MIS)',
  ],
  'Doctoral Degrees': [
    'Doctor of Philosophy (PhD)',
    'Doctor of Education (EdD)',
    'Doctor of Business Administration (DBA)',
    'Doctor of Engineering (DEng)',
    'Doctor of Science (DSc)',
    'Doctor of Arts (DA)',
    'Doctor of Music (DM)',
  ],
  'Professional Degrees': [
    'Juris Doctor (JD)',
    'Doctor of Medicine (MD)',
    'Doctor of Dental Surgery (DDS)',
    'Doctor of Veterinary Medicine (DVM)',
    'Doctor of Pharmacy (PharmD)',
    'Doctor of Physical Therapy (DPT)',
    'Doctor of Optometry (OD)',
    'Doctor of Nursing Practice (DNP)',
    'Master of Divinity (MDiv)',
  ],
  'Certificates & Diplomas': [
    'Professional Certificate',
    'Graduate Certificate',
    'Diploma',
    'Postgraduate Diploma',
    'Advanced Diploma',
    'Vocational Certificate',
    'Trade Certificate',
  ],
};

export function EducationForm({ data, onChange, onNext, onPrev }: EducationFormProps) {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [customDegreeInputs, setCustomDegreeInputs] = useState<{[key: number]: boolean}>({});

  const addEducation = () => {
    const newEducation = {
      id: crypto.randomUUID(),
      institution: '',
      degree: '',
      field: '',
      startDate: '',
      endDate: '',
      gpa: '',
      honors: '',
    };
    onChange([...data, newEducation]);
    setEditingIndex(data.length);
  };

  const updateEducation = (index: number, field: string, value: any) => {
    const updated = [...data];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  const removeEducation = (index: number) => {
    const updated = data.filter((_, i) => i !== index);
    onChange(updated);
    setEditingIndex(null);
    // Clean up custom degree input state
    const newCustomInputs = { ...customDegreeInputs };
    delete newCustomInputs[index];
    setCustomDegreeInputs(newCustomInputs);
  };

  const toggleCustomDegreeInput = (index: number) => {
    setCustomDegreeInputs(prev => ({
      ...prev,
      [index]: !prev[index]
    }));
    // Clear the degree field when switching modes
    updateEducation(index, 'degree', '');
  };

  const formatDateForInput = (dateString: string) => {
    if (!dateString) return '';
    // Handle both YYYY-MM and YYYY-MM-DD formats
    if (dateString.includes('-')) {
      const parts = dateString.split('-');
      return `${parts[0]}-${parts[1].padStart(2, '0')}`;
    }
    return dateString;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-5 w-5" />
            Education
          </div>
          <Button onClick={addEducation} size="sm" className="flex items-center gap-1">
            <Plus className="h-4 w-4" />
            Add Education
          </Button>
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Add your educational background, including degrees, certifications, and relevant coursework.
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {data.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <GraduationCap className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="font-medium mb-2">No education added yet</p>
            <p className="text-sm">Click "Add Education" to showcase your academic achievements.</p>
          </div>
        ) : (
          data.map((education, index) => (
            <Card key={education.id} className="border-l-4 border-l-blue-500">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium">
                      {education.degree || `Education ${index + 1}`}
                      {education.field && ` in ${education.field}`}
                    </h4>
                    <p className="text-sm text-muted-foreground mt-1">
                      {education.institution || 'Institution Name'}
                    </p>
                    {education.honors && (
                      <Badge variant="secondary" className="mt-2 text-xs">
                        {education.honors}
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setEditingIndex(editingIndex === index ? null : index)}
                    >
                      {editingIndex === index ? 'Collapse' : 'Edit'}
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => removeEducation(index)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              {editingIndex === index && (
                <CardContent className="space-y-4">
                  {/* Institution and Degree Row */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor={`institution-${index}`}>Institution *</Label>
                      <Input
                        id={`institution-${index}`}
                        value={education.institution}
                        onChange={(e) => updateEducation(index, 'institution', e.target.value)}
                        placeholder="e.g., Harvard University, MIT, Oxford"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label htmlFor={`degree-${index}`}>Degree *</Label>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleCustomDegreeInput(index)}
                          className="text-xs h-auto p-1"
                        >
                          {customDegreeInputs[index] ? 'Choose from list' : 'Type custom degree'}
                        </Button>
                      </div>
                      
                      {customDegreeInputs[index] ? (
                        <Input
                          id={`degree-custom-${index}`}
                          value={education.degree}
                          onChange={(e) => updateEducation(index, 'degree', e.target.value)}
                          placeholder="e.g., Bachelor of Interdisciplinary Studies"
                        />
                      ) : (
                        <Select
                          value={education.degree}
                          onValueChange={(value) => updateEducation(index, 'degree', value)}
                        >
                          <SelectTrigger id={`degree-${index}`}>
                            <SelectValue placeholder="Select degree type" />
                          </SelectTrigger>
                          <SelectContent className="max-h-[300px]">
                            {Object.entries(degreeCategories).map(([category, degrees]) => (
                              <div key={category}>
                                <div className="px-2 py-1.5 text-sm font-medium text-muted-foreground">
                                  {category}
                                </div>
                                {degrees.map((degree) => (
                                  <SelectItem key={degree} value={degree} className="pl-4">
                                    {degree}
                                  </SelectItem>
                                ))}
                              </div>
                            ))}
                          </SelectContent>
                        </Select>
                      )}
                    </div>
                  </div>

                  {/* Field of Study and GPA Row */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor={`field-${index}`}>Field of Study</Label>
                      <Input
                        id={`field-${index}`}
                        value={education.field}
                        onChange={(e) => updateEducation(index, 'field', e.target.value)}
                        placeholder="e.g., Computer Science, Business Administration"
                      />
                      <p className="text-xs text-muted-foreground">
                        Your major, concentration, or area of specialization
                      </p>
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor={`gpa-${index}`}>GPA (Optional)</Label>
                      <Input
                        id={`gpa-${index}`}
                        value={education.gpa || ''}
                        onChange={(e) => updateEducation(index, 'gpa', e.target.value)}
                        placeholder="e.g., 3.8/4.0, 85%, First Class"
                      />
                      <p className="text-xs text-muted-foreground">
                        Include only if 3.5+ or equivalent
                      </p>
                    </div>
                  </div>

                  <Separator />

                  {/* Dates Row */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor={`start-date-${index}`}>Start Date *</Label>
                      <Input
                        id={`start-date-${index}`}
                        type="month"
                        value={formatDateForInput(education.startDate)}
                        onChange={(e) => updateEducation(index, 'startDate', e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label htmlFor={`end-date-${index}`}>End Date *</Label>
                      <Input
                        id={`end-date-${index}`}
                        type="month"
                        value={formatDateForInput(education.endDate)}
                        onChange={(e) => updateEducation(index, 'endDate', e.target.value)}
                      />
                      <p className="text-xs text-muted-foreground">
                        Use expected graduation date if currently enrolled
                      </p>
                    </div>
                  </div>
                  
                  {/* Honors and Awards */}
                  <div className="space-y-2">
                    <Label htmlFor={`honors-${index}`}>Honors, Awards & Achievements (Optional)</Label>
                    <Input
                      id={`honors-${index}`}
                      value={education.honors || ''}
                      onChange={(e) => updateEducation(index, 'honors', e.target.value)}
                      placeholder="e.g., Magna Cum Laude, Dean's List, Phi Beta Kappa"
                    />
                    <p className="text-xs text-muted-foreground">
                      Include academic honors, scholarships, relevant coursework, or research projects
                    </p>
                  </div>
                </CardContent>
              )}
            </Card>
          ))
        )}

        {/* Helpful Tips Section */}
        {data.length === 0 && (
          <div className="bg-muted/50 rounded-lg p-4">
            <h4 className="font-medium mb-3">💡 Education Tips</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-muted-foreground">
              <div>
                <h5 className="font-medium text-foreground mb-2">What to Include:</h5>
                <ul className="space-y-1">
                  <li>• Degree and institution name</li>
                  <li>• Graduation year (or expected)</li>
                  <li>• GPA if 3.5 or higher</li>
                  <li>• Relevant honors or awards</li>
                </ul>
              </div>
              <div>
                <h5 className="font-medium text-foreground mb-2">Order & Priority:</h5>
                <ul className="space-y-1">
                  <li>• List most recent education first</li>
                  <li>• Include ongoing education</li>
                  <li>• Relevant certifications and training</li>
                  <li>• Skip high school if you have college</li>
                </ul>
              </div>
            </div>
          </div>
        )}
        
        {/* Navigation Buttons */}
        <div className="flex justify-between pt-6 border-t">
          <Button variant="outline" onClick={onPrev} className="flex items-center gap-2">
            <ChevronLeft className="h-4 w-4" />
            Experience
          </Button>
          <Button 
            onClick={onNext} 
            disabled={data.length === 0 || data.some(edu => !edu.institution || !edu.degree)}
            className="flex items-center gap-2"
          >
            Projects
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}