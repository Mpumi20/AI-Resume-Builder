import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Plus, Trash2, ExternalLink, Award, Calendar, ChevronRight, ChevronLeft } from 'lucide-react';

interface Certification {
  id: string;
  name: string;
  issuer: string;
  dateObtained: string;
  expiryDate?: string;
  credentialId?: string;
  verificationUrl?: string;
}

interface CertificationsFormProps {
  data: Certification[];
  onChange: (data: Certification[]) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function CertificationsForm({ data, onChange, onNext, onPrev }: CertificationsFormProps) {
  const [expandedCertification, setExpandedCertification] = useState<string | null>(null);

  const addCertification = () => {
    const newCertification: Certification = {
      id: crypto.randomUUID(),
      name: '',
      issuer: '',
      dateObtained: '',
      expiryDate: '',
      credentialId: '',
      verificationUrl: '',
    };
    onChange([...data, newCertification]);
    setExpandedCertification(newCertification.id);
  };

  const updateCertification = (id: string, field: keyof Certification, value: any) => {
    onChange(data.map(cert => 
      cert.id === id ? { ...cert, [field]: value } : cert
    ));
  };

  const removeCertification = (id: string) => {
    onChange(data.filter(cert => cert.id !== id));
    if (expandedCertification === id) {
      setExpandedCertification(null);
    }
  };

  const formatDateForInput = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '';
    return date.toISOString().split('T')[0];
  };

  const formatDisplayDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '';
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  const isExpired = (expiryDate: string) => {
    if (!expiryDate) return false;
    return new Date(expiryDate) < new Date();
  };

  const isExpiringSoon = (expiryDate: string) => {
    if (!expiryDate) return false;
    const expiry = new Date(expiryDate);
    const threeMonthsFromNow = new Date();
    threeMonthsFromNow.setMonth(threeMonthsFromNow.getMonth() + 3);
    return expiry < threeMonthsFromNow && expiry >= new Date();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Award className="h-5 w-5" />
          Certifications
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Add your professional certifications, licenses, and credentials to showcase your expertise.
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {data.length === 0 ? (
          <div className="text-center py-8">
            <Award className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground mb-4">No certifications added yet</p>
            <Button onClick={addCertification} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Your First Certification
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {data.map((certification, index) => (
              <Card key={certification.id} className="border-l-4 border-l-green-500">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium">
                        {certification.name || `Certification ${index + 1}`}
                      </h3>
                      {certification.issuer && (
                        <p className="text-sm text-muted-foreground mt-1">
                          Issued by {certification.issuer}
                        </p>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        {certification.dateObtained && (
                          <Badge variant="outline" className="text-xs">
                            <Calendar className="h-3 w-3 mr-1" />
                            {formatDisplayDate(certification.dateObtained)}
                          </Badge>
                        )}
                        {certification.expiryDate && (
                          <Badge 
                            variant={isExpired(certification.expiryDate) ? "destructive" : 
                                   isExpiringSoon(certification.expiryDate) ? "secondary" : "outline"}
                            className="text-xs"
                          >
                            {isExpired(certification.expiryDate) ? 'Expired' : 
                             isExpiringSoon(certification.expiryDate) ? 'Expires Soon' : 
                             `Expires ${formatDisplayDate(certification.expiryDate)}`}
                          </Badge>
                        )}
                        {certification.verificationUrl && (
                          <Badge variant="secondary" className="text-xs">
                            <ExternalLink className="h-3 w-3 mr-1" />
                            Verifiable
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedCertification(
                          expandedCertification === certification.id ? null : certification.id
                        )}
                      >
                        {expandedCertification === certification.id ? 'Collapse' : 'Edit'}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeCertification(certification.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {expandedCertification === certification.id && (
                  <CardContent className="space-y-4">
                    {/* Basic Information */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor={`cert-name-${certification.id}`}>Certification Name *</Label>
                        <Input
                          id={`cert-name-${certification.id}`}
                          value={certification.name}
                          onChange={(e) => updateCertification(certification.id, 'name', e.target.value)}
                          placeholder="e.g., AWS Certified Solutions Architect"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor={`cert-issuer-${certification.id}`}>Issuing Organization *</Label>
                        <Input
                          id={`cert-issuer-${certification.id}`}
                          value={certification.issuer}
                          onChange={(e) => updateCertification(certification.id, 'issuer', e.target.value)}
                          placeholder="e.g., Amazon Web Services"
                        />
                      </div>
                    </div>

                    {/* Dates */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor={`date-obtained-${certification.id}`}>Date Obtained *</Label>
                        <Input
                          id={`date-obtained-${certification.id}`}
                          type="date"
                          value={formatDateForInput(certification.dateObtained)}
                          onChange={(e) => updateCertification(certification.id, 'dateObtained', e.target.value)}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor={`expiry-date-${certification.id}`}>Expiry Date (Optional)</Label>
                        <Input
                          id={`expiry-date-${certification.id}`}
                          type="date"
                          value={formatDateForInput(certification.expiryDate || '')}
                          onChange={(e) => updateCertification(certification.id, 'expiryDate', e.target.value)}
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Leave blank if certification doesn't expire
                        </p>
                      </div>
                    </div>

                    <Separator />

                    {/* Additional Information */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor={`credential-id-${certification.id}`}>Credential ID (Optional)</Label>
                        <Input
                          id={`credential-id-${certification.id}`}
                          value={certification.credentialId || ''}
                          onChange={(e) => updateCertification(certification.id, 'credentialId', e.target.value)}
                          placeholder="e.g., ABC123XYZ"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Certificate or license number
                        </p>
                      </div>
                      
                      <div>
                        <Label htmlFor={`verification-url-${certification.id}`} className="flex items-center gap-1">
                          <ExternalLink className="h-3 w-3" />
                          Verification URL (Optional)
                        </Label>
                        <Input
                          id={`verification-url-${certification.id}`}
                          value={certification.verificationUrl || ''}
                          onChange={(e) => updateCertification(certification.id, 'verificationUrl', e.target.value)}
                          placeholder="https://verify.example.com/certificate"
                          type="url"
                        />
                        <p className="text-xs text-muted-foreground mt-1">
                          Link to verify this certification
                        </p>
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}

            <Button
              variant="outline"
              onClick={addCertification}
              className="w-full flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Add Another Certification
            </Button>
          </div>
        )}

        {/* Popular Certifications Suggestions */}
        {data.length === 0 && (
          <div className="bg-muted/50 rounded-lg p-4">
            <h4 className="font-medium mb-3">Popular Certifications by Field:</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <h5 className="font-medium text-blue-600 mb-2">Technology</h5>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• AWS Certified Solutions Architect</li>
                  <li>• Google Cloud Professional</li>
                  <li>• Microsoft Azure Fundamentals</li>
                  <li>• Certified Kubernetes Administrator</li>
                </ul>
              </div>
              <div>
                <h5 className="font-medium text-green-600 mb-2">Project Management</h5>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• PMP (Project Management Professional)</li>
                  <li>• Certified ScrumMaster (CSM)</li>
                  <li>• PRINCE2 Foundation</li>
                  <li>• Agile Certified Practitioner</li>
                </ul>
              </div>
            </div>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex justify-between pt-6 border-t">
          <Button variant="outline" onClick={onPrev} className="flex items-center gap-2">
            <ChevronLeft className="h-4 w-4" />
            Projects
          </Button>
          <Button onClick={onNext} className="flex items-center gap-2">
            Skills
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}