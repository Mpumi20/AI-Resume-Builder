import React from 'react';
import { Badge } from './ui/badge';
import { Card } from './ui/card';
import { Mail, Phone, MapPin, Globe, Linkedin, Calendar, ExternalLink, Github, Award } from 'lucide-react';
import type { ResumeData } from '../App';

interface ResumePreviewProps {
  data: ResumeData;
  template: 'modern' | 'classic' | 'creative';
  isPDFMode?: boolean;
}

export function ResumePreview({ data, template, isPDFMode = false }: ResumePreviewProps) {
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
  };

  const ModernTemplate = () => (
    <div 
      className={`bg-white text-black p-8 ${!isPDFMode ? 'shadow-lg min-h-[800px]' : ''} w-full ${isPDFMode ? 'max-w-none' : 'max-w-4xl mx-auto'}`} 
      data-resume-preview
      style={isPDFMode ? { 
        backgroundColor: '#ffffff', 
        color: '#000000', 
        padding: '2rem', 
        width: '100%',
        overflow: 'visible',
        height: 'auto',
        minHeight: 'auto',
        wordWrap: 'break-word',
        overflowWrap: 'break-word'
      } : {}}
    >
      {/* Header - Center Aligned */}
      <div 
        className="text-center border-b-2 border-blue-600 pb-6 mb-8" 
        style={{ textAlign: 'center', borderBottom: '2px solid #2563eb', paddingBottom: '1.5rem', marginBottom: '2rem' }}
      >
        <h1 
          className="text-3xl font-bold text-gray-900 mb-4" 
          style={{ textAlign: 'center', fontSize: '1.875rem', fontWeight: '700', color: '#111827', marginBottom: '1rem' }}
        >
          {data.personalInfo.fullName || 'Your Name'}
        </h1>
        <div 
          className="flex flex-wrap justify-center gap-6 text-sm text-gray-600" 
          style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '1.5rem', fontSize: '0.875rem', color: '#4b5563' }}
        >
          {data.personalInfo.email && (
            <div className="flex items-center gap-1" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              {!isPDFMode && <Mail className="h-4 w-4" />}
              <span>{isPDFMode ? '📧 ' : ''}{data.personalInfo.email}</span>
            </div>
          )}
          {data.personalInfo.phone && (
            <div className="flex items-center gap-1" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              {!isPDFMode && <Phone className="h-4 w-4" />}
              <span>{isPDFMode ? '📞 ' : ''}{data.personalInfo.phone}</span>
            </div>
          )}
          {data.personalInfo.location && (
            <div className="flex items-center gap-1" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              {!isPDFMode && <MapPin className="h-4 w-4" />}
              <span>{isPDFMode ? '📍 ' : ''}{data.personalInfo.location}</span>
            </div>
          )}
          {data.personalInfo.linkedIn && (
            <div className="flex items-center gap-1" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              {!isPDFMode && <Linkedin className="h-4 w-4" />}
              <span>{isPDFMode ? '🔗 ' : ''}{data.personalInfo.linkedIn}</span>
            </div>
          )}
          {data.personalInfo.website && (
            <div className="flex items-center gap-1" style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}>
              {!isPDFMode && <Globe className="h-4 w-4" />}
              <span>{isPDFMode ? '🌐 ' : ''}{data.personalInfo.website}</span>
            </div>
          )}
        </div>
      </div>

      {/* Summary - Center Aligned */}
      {data.personalInfo.summary && (
        <div 
          className="mb-8 text-center" 
          style={{ marginBottom: '2rem', textAlign: 'center' }}
        >
          <h2 
            className="text-xl font-semibold text-blue-600 mb-4" 
            style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600', color: '#2563eb', marginBottom: '1rem' }}
          >
            Professional Summary
          </h2>
          <p 
            className="text-gray-700 leading-relaxed max-w-4xl mx-auto" 
            style={{ 
              textAlign: 'center', 
              color: '#374151', 
              lineHeight: '1.625', 
              maxWidth: isPDFMode ? 'none' : '56rem', 
              marginLeft: 'auto', 
              marginRight: 'auto',
              wordWrap: 'break-word',
              overflowWrap: 'break-word',
              whiteSpace: 'normal',
              overflow: 'visible'
            }}
          >
            {data.personalInfo.summary}
          </p>
        </div>
      )}

      {/* Experience - Center Aligned Content */}
      {data.experience.length > 0 && (
        <div className="mb-8" style={{ marginBottom: '2rem' }}>
          <h2 
            className="text-xl font-semibold text-blue-600 mb-6 text-center" 
            style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600', color: '#2563eb', marginBottom: '1.5rem' }}
          >
            Experience
          </h2>
          <div className="space-y-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {data.experience.map((exp) => (
              <div key={exp.id} className="text-center" style={{ textAlign: 'center' }}>
                <div className="mb-3" style={{ marginBottom: '0.75rem' }}>
                  <h3 
                    className="font-semibold text-gray-900 text-lg" 
                    style={{ textAlign: 'center', fontWeight: '600', color: '#111827', fontSize: '1.125rem' }}
                  >
                    {exp.position}
                  </h3>
                  <p 
                    className="text-blue-600 font-medium text-base" 
                    style={{ textAlign: 'center', color: '#2563eb', fontWeight: '500', fontSize: '1rem' }}
                  >
                    {exp.company}
                  </p>
                  <div 
                    className="text-sm text-gray-600 flex items-center justify-center gap-1 mt-1" 
                    style={{ fontSize: '0.875rem', color: '#4b5563', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.25rem', marginTop: '0.25rem' }}
                  >
                    {!isPDFMode && <Calendar className="h-3 w-3" />}
                    <span>{isPDFMode ? '📅 ' : ''}{formatDate(exp.startDate)} - {exp.current ? 'Present' : formatDate(exp.endDate)}</span>
                  </div>
                </div>
                {exp.description && (
                  <p 
                    className="text-gray-700 mb-3 max-w-3xl mx-auto leading-relaxed" 
                    style={{ 
                      textAlign: 'center', 
                      color: '#374151', 
                      marginBottom: '0.75rem', 
                      maxWidth: isPDFMode ? 'none' : '48rem', 
                      marginLeft: 'auto', 
                      marginRight: 'auto', 
                      lineHeight: '1.625',
                      wordWrap: 'break-word',
                      overflowWrap: 'break-word',
                      whiteSpace: 'normal',
                      overflow: 'visible'
                    }}
                  >
                    {exp.description}
                  </p>
                )}
                {exp.achievements.length > 0 && (
                  <div 
                    className="max-w-3xl mx-auto" 
                    style={{ 
                      maxWidth: isPDFMode ? 'none' : '48rem', 
                      marginLeft: 'auto', 
                      marginRight: 'auto',
                      width: isPDFMode ? '100%' : 'auto',
                      overflow: 'visible'
                    }}
                  >
                    <ul 
                      className="list-disc list-inside space-y-2 text-left" 
                      style={{ 
                        listStyleType: 'disc', 
                        listStylePosition: 'inside', 
                        display: 'flex', 
                        flexDirection: 'column', 
                        gap: '0.5rem', 
                        textAlign: 'left',
                        overflow: 'visible',
                        wordWrap: 'break-word',
                        overflowWrap: 'break-word'
                      }}
                    >
                      {exp.achievements.filter(a => a.trim()).map((achievement, index) => (
                        <li 
                          key={index} 
                          className="text-gray-700 text-sm leading-relaxed" 
                          style={{ 
                            color: '#374151', 
                            fontSize: '0.875rem', 
                            lineHeight: '1.625',
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word',
                            whiteSpace: 'normal',
                            overflow: 'visible'
                          }}
                        >
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Projects - Center Aligned Content */}
      {data.projects.length > 0 && (
        <div className="mb-8" style={{ marginBottom: '2rem' }}>
          <h2 
            className="text-xl font-semibold text-blue-600 mb-6 text-center"
            style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600', color: '#2563eb', marginBottom: '1.5rem' }}
          >
            Projects
          </h2>
          <div className="space-y-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {data.projects.map((project) => (
              <div key={project.id} className="text-center" style={{ textAlign: 'center' }}>
                <div className="mb-3" style={{ marginBottom: '0.75rem' }}>
                  <h3 
                    className="font-semibold text-gray-900 text-lg"
                    style={{ textAlign: 'center', fontWeight: '600', color: '#111827', fontSize: '1.125rem' }}
                  >
                    {project.name}
                  </h3>
                  <div 
                    className="flex items-center justify-center gap-3 mt-2"
                    style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem', marginTop: '0.5rem' }}
                  >
                    {project.url && (
                      <div className="flex items-center gap-1 text-blue-600 text-xs">
                        {!isPDFMode && <ExternalLink className="h-3 w-3" />}
                        <span>{isPDFMode ? '🔗 ' : ''}Demo</span>
                      </div>
                    )}
                    {project.githubUrl && (
                      <div className="flex items-center gap-1 text-gray-600 text-xs">
                        {!isPDFMode && <Github className="h-3 w-3" />}
                        <span>{isPDFMode ? '💻 ' : ''}Code</span>
                      </div>
                    )}
                  </div>
                  <div 
                    className="text-sm text-gray-600 flex items-center justify-center gap-1 mt-1"
                    style={{ fontSize: '0.875rem', color: '#4b5563', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.25rem', marginTop: '0.25rem' }}
                  >
                    {!isPDFMode && <Calendar className="h-3 w-3" />}
                    <span>{isPDFMode ? '📅 ' : ''}{formatDate(project.startDate)} - {project.current ? 'Present' : formatDate(project.endDate)}</span>
                  </div>
                </div>
                {project.description && (
                  <p 
                    className="text-gray-700 mb-3 max-w-3xl mx-auto leading-relaxed"
                    style={{ 
                      textAlign: 'center', 
                      color: '#374151', 
                      marginBottom: '0.75rem', 
                      maxWidth: isPDFMode ? 'none' : '48rem', 
                      marginLeft: 'auto', 
                      marginRight: 'auto', 
                      lineHeight: '1.625',
                      wordWrap: 'break-word',
                      overflowWrap: 'break-word',
                      whiteSpace: 'normal',
                      overflow: 'visible'
                    }}
                  >
                    {project.description}
                  </p>
                )}
                {project.technologies.length > 0 && (
                  <div 
                    className="flex flex-wrap justify-center gap-2 mb-3"
                    style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '0.5rem', marginBottom: '0.75rem' }}
                  >
                    {project.technologies.filter(t => t.trim()).map((tech, index) => (
                      <span 
                        key={index} 
                        className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs"
                        style={{ backgroundColor: '#f3f4f6', color: '#374151', padding: '0.25rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.75rem' }}
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                )}
                {project.achievements.length > 0 && (
                  <div 
                    className="max-w-3xl mx-auto"
                    style={{ 
                      maxWidth: isPDFMode ? 'none' : '48rem', 
                      marginLeft: 'auto', 
                      marginRight: 'auto',
                      width: isPDFMode ? '100%' : 'auto',
                      overflow: 'visible'
                    }}
                  >
                    <ul 
                      className="list-disc list-inside space-y-2 text-left"
                      style={{ 
                        listStyleType: 'disc', 
                        listStylePosition: 'inside', 
                        display: 'flex', 
                        flexDirection: 'column', 
                        gap: '0.5rem', 
                        textAlign: 'left',
                        overflow: 'visible',
                        wordWrap: 'break-word',
                        overflowWrap: 'break-word'
                      }}
                    >
                      {project.achievements.filter(a => a.trim()).map((achievement, index) => (
                        <li 
                          key={index} 
                          className="text-gray-700 text-sm leading-relaxed"
                          style={{ 
                            color: '#374151', 
                            fontSize: '0.875rem', 
                            lineHeight: '1.625',
                            wordWrap: 'break-word',
                            overflowWrap: 'break-word',
                            whiteSpace: 'normal',
                            overflow: 'visible'
                          }}
                        >
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Education - Center Aligned Content */}
      {data.education.length > 0 && (
        <div className="mb-8" style={{ marginBottom: '2rem' }}>
          <h2 
            className="text-xl font-semibold text-blue-600 mb-6 text-center"
            style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600', color: '#2563eb', marginBottom: '1.5rem' }}
          >
            Education
          </h2>
          <div className="space-y-4" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {data.education.map((edu) => (
              <div key={edu.id} className="text-center" style={{ textAlign: 'center' }}>
                <h3 
                  className="font-semibold text-gray-900 text-lg"
                  style={{ textAlign: 'center', fontWeight: '600', color: '#111827', fontSize: '1.125rem' }}
                >
                  {edu.degree} {edu.field && `in ${edu.field}`}
                </h3>
                <p 
                  className="text-blue-600 font-medium"
                  style={{ textAlign: 'center', color: '#2563eb', fontWeight: '500' }}
                >
                  {edu.institution}
                </p>
                <div 
                  className="text-sm text-gray-600 flex items-center justify-center gap-1 mt-1"
                  style={{ fontSize: '0.875rem', color: '#4b5563', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.25rem', marginTop: '0.25rem' }}
                >
                  {!isPDFMode && <Calendar className="h-3 w-3" />}
                  <span>{isPDFMode ? '📅 ' : ''}{formatDate(edu.startDate)} - {formatDate(edu.endDate)}</span>
                </div>
                {edu.honors && (
                  <p 
                    className="text-sm text-gray-600 mt-1"
                    style={{ textAlign: 'center', fontSize: '0.875rem', color: '#4b5563', marginTop: '0.25rem' }}
                  >
                    {edu.honors}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Certifications - Center Aligned Content */}
      {data.certifications.length > 0 && (
        <div className="mb-8" style={{ marginBottom: '2rem' }}>
          <h2 
            className="text-xl font-semibold text-blue-600 mb-6 text-center"
            style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600', color: '#2563eb', marginBottom: '1.5rem' }}
          >
            Certifications
          </h2>
          <div className="space-y-4" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {data.certifications.map((cert) => (
              <div key={cert.id} className="text-center" style={{ textAlign: 'center' }}>
                <h3 
                  className="font-semibold text-gray-900 text-lg"
                  style={{ textAlign: 'center', fontWeight: '600', color: '#111827', fontSize: '1.125rem' }}
                >
                  {cert.name}
                </h3>
                <p 
                  className="text-blue-600 font-medium"
                  style={{ textAlign: 'center', color: '#2563eb', fontWeight: '500' }}
                >
                  {cert.issuer}
                </p>
                <div 
                  className="text-sm text-gray-600 flex items-center justify-center gap-1 mt-1"
                  style={{ fontSize: '0.875rem', color: '#4b5563', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.25rem', marginTop: '0.25rem' }}
                >
                  {!isPDFMode && <Award className="h-3 w-3" />}
                  <span>{isPDFMode ? '🏆 ' : ''}{formatDate(cert.dateObtained)}</span>
                  {cert.expiryDate && <span> - {formatDate(cert.expiryDate)}</span>}
                </div>
                {cert.credentialId && (
                  <p 
                    className="text-sm text-gray-600 mt-1"
                    style={{ textAlign: 'center', fontSize: '0.875rem', color: '#4b5563', marginTop: '0.25rem' }}
                  >
                    ID: {cert.credentialId}
                  </p>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills - Center Aligned */}
      <div className="space-y-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        {data.skills.technical.length > 0 && (
          <div className="text-center" style={{ textAlign: 'center' }}>
            <h2 
              className="text-xl font-semibold text-blue-600 mb-4"
              style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600', color: '#2563eb', marginBottom: '1rem' }}
            >
              Technical Skills
            </h2>
            <div 
              className="flex flex-wrap justify-center gap-2 max-w-4xl mx-auto"
              style={{ 
                display: 'flex', 
                flexWrap: 'wrap', 
                justifyContent: 'center', 
                gap: '0.5rem', 
                maxWidth: isPDFMode ? 'none' : '56rem', 
                marginLeft: 'auto', 
                marginRight: 'auto',
                overflow: 'visible',
                width: isPDFMode ? '100%' : 'auto'
              }}
            >
              {data.skills.technical.map((skill, index) => (
                <span 
                  key={index} 
                  className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                  style={{ 
                    backgroundColor: '#dbeafe', 
                    color: '#1e40af', 
                    padding: '0.25rem 0.75rem', 
                    borderRadius: '9999px', 
                    fontSize: '0.875rem',
                    wordWrap: 'break-word',
                    overflow: 'visible'
                  }}
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}

        {data.skills.soft.length > 0 && (
          <div className="text-center" style={{ textAlign: 'center' }}>
            <h2 
              className="text-xl font-semibold text-blue-600 mb-4"
              style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600', color: '#2563eb', marginBottom: '1rem' }}
            >
              Core Competencies
            </h2>
            <div 
              className="flex flex-wrap justify-center gap-2 max-w-4xl mx-auto"
              style={{ 
                display: 'flex', 
                flexWrap: 'wrap', 
                justifyContent: 'center', 
                gap: '0.5rem', 
                maxWidth: isPDFMode ? 'none' : '56rem', 
                marginLeft: 'auto', 
                marginRight: 'auto',
                overflow: 'visible',
                width: isPDFMode ? '100%' : 'auto'
              }}
            >
              {data.skills.soft.map((skill, index) => (
                <span 
                  key={index} 
                  className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                  style={{ 
                    backgroundColor: '#f3f4f6', 
                    color: '#374151', 
                    padding: '0.25rem 0.75rem', 
                    borderRadius: '9999px', 
                    fontSize: '0.875rem',
                    wordWrap: 'break-word',
                    overflow: 'visible'
                  }}
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        )}

        {data.skills.languages.length > 0 && (
          <div className="text-center" style={{ textAlign: 'center' }}>
            <h2 
              className="text-xl font-semibold text-blue-600 mb-4"
              style={{ textAlign: 'center', fontSize: '1.25rem', fontWeight: '600', color: '#2563eb', marginBottom: '1rem' }}
            >
              Languages
            </h2>
            <div 
              className="flex flex-wrap justify-center gap-2 max-w-4xl mx-auto"
              style={{ 
                display: 'flex', 
                flexWrap: 'wrap', 
                justifyContent: 'center', 
                gap: '0.5rem', 
                maxWidth: isPDFMode ? 'none' : '56rem', 
                marginLeft: 'auto', 
                marginRight: 'auto',
                overflow: 'visible',
                width: isPDFMode ? '100%' : 'auto'
              }}
            >
              {data.skills.languages.map((language, index) => (
                <span 
                  key={index} 
                  className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm"
                  style={{ 
                    backgroundColor: '#dcfce7', 
                    color: '#166534', 
                    padding: '0.25rem 0.75rem', 
                    borderRadius: '9999px', 
                    fontSize: '0.875rem',
                    wordWrap: 'break-word',
                    overflow: 'visible'
                  }}
                >
                  {language}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const ClassicTemplate = () => (
    <div 
      className={`bg-white text-black p-8 min-h-[800px] ${!isPDFMode ? 'shadow-lg' : ''} w-full ${isPDFMode ? 'max-w-none' : 'max-w-4xl mx-auto'}`} 
      data-resume-preview
      style={isPDFMode ? { backgroundColor: '#ffffff', color: '#000000', padding: '2rem', minHeight: '800px', width: '100%' } : {}}
    >
      {/* Header - Center Aligned */}
      <div 
        className="text-center border-b pb-6 mb-8"
        style={{ textAlign: 'center', borderBottom: '1px solid #d1d5db', paddingBottom: '1.5rem', marginBottom: '2rem' }}
      >
        <h1 
          className="text-2xl font-bold text-gray-900 mb-4"
          style={{ textAlign: 'center', fontSize: '1.5rem', fontWeight: '700', color: '#111827', marginBottom: '1rem' }}
        >
          {data.personalInfo.fullName || 'Your Name'}
        </h1>
        <div 
          className="text-sm text-gray-600 space-y-1"
          style={{ fontSize: '0.875rem', color: '#4b5563', display: 'flex', flexDirection: 'column', gap: '0.25rem', textAlign: 'center' }}
        >
          {data.personalInfo.email && <div>{data.personalInfo.email}</div>}
          {data.personalInfo.phone && <div>{data.personalInfo.phone}</div>}
          {data.personalInfo.location && <div>{data.personalInfo.location}</div>}
          {data.personalInfo.linkedIn && <div>{data.personalInfo.linkedIn}</div>}
          {data.personalInfo.website && <div>{data.personalInfo.website}</div>}
        </div>
      </div>

      {/* Summary - Center Aligned */}
      {data.personalInfo.summary && (
        <div 
          className="mb-8 text-center"
          style={{ marginBottom: '2rem', textAlign: 'center' }}
        >
          <h2 
            className="text-lg font-bold text-gray-900 border-b border-gray-300 pb-2 mb-4 inline-block"
            style={{ fontSize: '1.125rem', fontWeight: '700', color: '#111827', borderBottom: '1px solid #d1d5db', paddingBottom: '0.5rem', marginBottom: '1rem', display: 'inline-block' }}
          >
            PROFESSIONAL SUMMARY
          </h2>
          <p 
            className="text-gray-700 max-w-4xl mx-auto leading-relaxed"
            style={{ textAlign: 'center', color: '#374151', maxWidth: '56rem', marginLeft: 'auto', marginRight: 'auto', lineHeight: '1.625' }}
          >
            {data.personalInfo.summary}
          </p>
        </div>
      )}

      {/* Experience */}
      {data.experience.length > 0 && (
        <div className="mb-8" style={{ marginBottom: '2rem' }}>
          <h2 
            className="text-lg font-bold text-gray-900 border-b border-gray-300 pb-2 mb-6 text-center"
            style={{ textAlign: 'center', fontSize: '1.125rem', fontWeight: '700', color: '#111827', borderBottom: '1px solid #d1d5db', paddingBottom: '0.5rem', marginBottom: '1.5rem' }}
          >
            PROFESSIONAL EXPERIENCE
          </h2>
          <div className="space-y-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
            {data.experience.map((exp) => (
              <div key={exp.id} className="text-center" style={{ textAlign: 'center' }}>
                <h3 
                  className="font-bold text-gray-900 text-lg"
                  style={{ textAlign: 'center', fontWeight: '700', color: '#111827', fontSize: '1.125rem' }}
                >
                  {exp.position}
                </h3>
                <p 
                  className="font-semibold text-gray-700 mb-1"
                  style={{ textAlign: 'center', fontWeight: '600', color: '#374151', marginBottom: '0.25rem' }}
                >
                  {exp.company}
                </p>
                <span 
                  className="text-sm text-gray-600"
                  style={{ fontSize: '0.875rem', color: '#4b5563' }}
                >
                  {formatDate(exp.startDate)} - {exp.current ? 'Present' : formatDate(exp.endDate)}
                </span>
                {exp.description && (
                  <p 
                    className="text-gray-700 mt-3 mb-3 max-w-3xl mx-auto leading-relaxed"
                    style={{ textAlign: 'center', color: '#374151', marginTop: '0.75rem', marginBottom: '0.75rem', maxWidth: '48rem', marginLeft: 'auto', marginRight: 'auto', lineHeight: '1.625' }}
                  >
                    {exp.description}
                  </p>
                )}
                {exp.achievements.length > 0 && (
                  <div 
                    className="max-w-3xl mx-auto mt-3"
                    style={{ maxWidth: '48rem', marginLeft: 'auto', marginRight: 'auto', marginTop: '0.75rem' }}
                  >
                    <ul 
                      className="list-disc list-inside space-y-2 text-left"
                      style={{ listStyleType: 'disc', listStylePosition: 'inside', display: 'flex', flexDirection: 'column', gap: '0.5rem', textAlign: 'left' }}
                    >
                      {exp.achievements.filter(a => a.trim()).map((achievement, index) => (
                        <li 
                          key={index} 
                          className="text-gray-700 text-sm leading-relaxed"
                          style={{ color: '#374151', fontSize: '0.875rem', lineHeight: '1.625' }}
                        >
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Skills - Center Aligned */}
      {(data.skills.technical.length > 0 || data.skills.soft.length > 0 || data.skills.languages.length > 0) && (
        <div className="mb-8" style={{ marginBottom: '2rem' }}>
          <h2 
            className="text-lg font-bold text-gray-900 border-b border-gray-300 pb-2 mb-6 text-center"
            style={{ textAlign: 'center', fontSize: '1.125rem', fontWeight: '700', color: '#111827', borderBottom: '1px solid #d1d5db', paddingBottom: '0.5rem', marginBottom: '1.5rem' }}
          >
            SKILLS
          </h2>
          <div className="space-y-4 text-center" style={{ display: 'flex', flexDirection: 'column', gap: '1rem', textAlign: 'center' }}>
            {data.skills.technical.length > 0 && (
              <div>
                <p 
                  className="font-semibold text-gray-900 mb-2"
                  style={{ fontWeight: '600', color: '#111827', marginBottom: '0.5rem' }}
                >
                  Technical:
                </p>
                <p 
                  className="text-gray-700 max-w-4xl mx-auto"
                  style={{ color: '#374151', maxWidth: '56rem', marginLeft: 'auto', marginRight: 'auto' }}
                >
                  {data.skills.technical.join(', ')}
                </p>
              </div>
            )}
            {data.skills.soft.length > 0 && (
              <div>
                <p 
                  className="font-semibold text-gray-900 mb-2"
                  style={{ fontWeight: '600', color: '#111827', marginBottom: '0.5rem' }}
                >
                  Core Competencies:
                </p>
                <p 
                  className="text-gray-700 max-w-4xl mx-auto"
                  style={{ color: '#374151', maxWidth: '56rem', marginLeft: 'auto', marginRight: 'auto' }}
                >
                  {data.skills.soft.join(', ')}
                </p>
              </div>
            )}
            {data.skills.languages.length > 0 && (
              <div>
                <p 
                  className="font-semibold text-gray-900 mb-2"
                  style={{ fontWeight: '600', color: '#111827', marginBottom: '0.5rem' }}
                >
                  Languages:
                </p>
                <p 
                  className="text-gray-700 max-w-4xl mx-auto"
                  style={{ color: '#374151', maxWidth: '56rem', marginLeft: 'auto', marginRight: 'auto' }}
                >
                  {data.skills.languages.join(', ')}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );

  const CreativeTemplate = () => (
    <div 
      className={`bg-gradient-to-br from-purple-50 to-blue-50 text-black p-8 ${!isPDFMode ? 'shadow-lg min-h-[800px]' : ''} w-full ${isPDFMode ? 'max-w-none' : 'max-w-4xl mx-auto'}`} 
      data-resume-preview
      style={isPDFMode ? { 
        background: 'linear-gradient(135deg, #fdf4ff 0%, #eff6ff 100%)', 
        color: '#000000', 
        padding: '2rem', 
        width: '100%',
        overflow: 'visible',
        height: 'auto',
        minHeight: 'auto',
        wordWrap: 'break-word',
        overflowWrap: 'break-word'
      } : {}}
    >
      {/* Header - Center Aligned */}
      <div 
        className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6 rounded-lg mb-8 text-center"
        style={{ background: 'linear-gradient(to right, #9333ea, #2563eb)', color: '#ffffff', padding: '1.5rem', borderRadius: '0.5rem', marginBottom: '2rem', textAlign: 'center' }}
      >
        <h1 
          className="text-3xl font-bold mb-4"
          style={{ fontSize: '1.875rem', fontWeight: '700', marginBottom: '1rem', textAlign: 'center' }}
        >
          {data.personalInfo.fullName || 'Your Name'}
        </h1>
        <div 
          className="flex flex-wrap justify-center gap-4 text-sm"
          style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '1rem', fontSize: '0.875rem' }}
        >
          {data.personalInfo.email && (
            <div className="flex items-center gap-2">
              {!isPDFMode && <Mail className="h-4 w-4" />}
              <span>{isPDFMode ? '📧 ' : ''}{data.personalInfo.email}</span>
            </div>
          )}
          {data.personalInfo.phone && (
            <div className="flex items-center gap-2">
              {!isPDFMode && <Phone className="h-4 w-4" />}
              <span>{isPDFMode ? '📞 ' : ''}{data.personalInfo.phone}</span>
            </div>
          )}
          {data.personalInfo.location && (
            <div className="flex items-center gap-2">
              {!isPDFMode && <MapPin className="h-4 w-4" />}
              <span>{isPDFMode ? '📍 ' : ''}{data.personalInfo.location}</span>
            </div>
          )}
          {data.personalInfo.linkedIn && (
            <div className="flex items-center gap-2">
              {!isPDFMode && <Linkedin className="h-4 w-4" />}
              <span>{isPDFMode ? '🔗 ' : ''}{data.personalInfo.linkedIn}</span>
            </div>
          )}
          {data.personalInfo.website && (
            <div className="flex items-center gap-2">
              {!isPDFMode && <Globe className="h-4 w-4" />}
              <span>{isPDFMode ? '🌐 ' : ''}{data.personalInfo.website}</span>
            </div>
          )}
        </div>
      </div>

      {/* Summary - Center Aligned */}
      {data.personalInfo.summary && (
        <div 
          className={`bg-white rounded-lg p-6 mb-8 ${!isPDFMode ? 'shadow-sm' : ''} text-center`}
          style={{ backgroundColor: '#ffffff', borderRadius: '0.5rem', padding: '1.5rem', marginBottom: '2rem', textAlign: 'center' }}
        >
          <h2 
            className="text-xl font-bold text-purple-600 mb-4"
            style={{ fontSize: '1.25rem', fontWeight: '700', color: '#9333ea', marginBottom: '1rem' }}
          >
            About Me
          </h2>
          <p 
            className="text-gray-700 leading-relaxed max-w-4xl mx-auto"
            style={{ 
              color: '#374151', 
              lineHeight: '1.625', 
              maxWidth: isPDFMode ? 'none' : '56rem', 
              marginLeft: 'auto', 
              marginRight: 'auto',
              wordWrap: 'break-word',
              overflowWrap: 'break-word',
              whiteSpace: 'normal',
              overflow: 'visible'
            }}
          >
            {data.personalInfo.summary}
          </p>
        </div>
      )}

      {/* Main Content - Center Aligned Single Column */}
      <div className="space-y-8" style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
        {/* Experience */}
        {data.experience.length > 0 && (
          <div 
            className={`bg-white rounded-lg p-6 ${!isPDFMode ? 'shadow-sm' : ''}`}
            style={{ backgroundColor: '#ffffff', borderRadius: '0.5rem', padding: '1.5rem' }}
          >
            <h2 
              className="text-xl font-bold text-purple-600 mb-6 text-center"
              style={{ fontSize: '1.25rem', fontWeight: '700', color: '#9333ea', marginBottom: '1.5rem', textAlign: 'center' }}
            >
              Experience
            </h2>
            <div className="space-y-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {data.experience.map((exp) => (
                <div key={exp.id} className="text-center" style={{ textAlign: 'center' }}>
                  <h3 
                    className="font-bold text-gray-900 text-lg"
                    style={{ fontWeight: '700', color: '#111827', fontSize: '1.125rem', textAlign: 'center' }}
                  >
                    {exp.position}
                  </h3>
                  <p 
                    className="text-purple-600 font-semibold"
                    style={{ color: '#9333ea', fontWeight: '600', textAlign: 'center' }}
                  >
                    {exp.company}
                  </p>
                  <span 
                    className="bg-purple-100 text-purple-700 px-3 py-1 rounded-full text-xs inline-block mt-2"
                    style={{ backgroundColor: '#ede9fe', color: '#7c3aed', padding: '0.25rem 0.75rem', borderRadius: '9999px', fontSize: '0.75rem', display: 'inline-block', marginTop: '0.5rem' }}
                  >
                    {formatDate(exp.startDate)} - {exp.current ? 'Now' : formatDate(exp.endDate)}
                  </span>
                  {exp.description && (
                    <p 
                      className="text-gray-700 mt-3 mb-3 max-w-3xl mx-auto leading-relaxed"
                      style={{ 
                        color: '#374151', 
                        marginTop: '0.75rem', 
                        marginBottom: '0.75rem', 
                        maxWidth: isPDFMode ? 'none' : '48rem', 
                        marginLeft: 'auto', 
                        marginRight: 'auto', 
                        lineHeight: '1.625',
                        textAlign: 'center',
                        wordWrap: 'break-word',
                        overflowWrap: 'break-word',
                        whiteSpace: 'normal',
                        overflow: 'visible'
                      }}
                    >
                      {exp.description}
                    </p>
                  )}
                  {exp.achievements.length > 0 && (
                    <div 
                      className="max-w-3xl mx-auto mt-3"
                      style={{ 
                        maxWidth: isPDFMode ? 'none' : '48rem', 
                        marginLeft: 'auto', 
                        marginRight: 'auto', 
                        marginTop: '0.75rem',
                        width: isPDFMode ? '100%' : 'auto',
                        overflow: 'visible'
                      }}
                    >
                      <ul 
                        className="space-y-2 text-left"
                        style={{ 
                          display: 'flex', 
                          flexDirection: 'column', 
                          gap: '0.5rem', 
                          textAlign: 'left',
                          overflow: 'visible',
                          wordWrap: 'break-word',
                          overflowWrap: 'break-word'
                        }}
                      >
                        {exp.achievements.filter(a => a.trim()).map((achievement, index) => (
                          <li 
                            key={index} 
                            className="flex items-start gap-2 justify-center"
                            style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', justifyContent: 'center' }}
                          >
                            <div 
                              className="w-2 h-2 bg-purple-400 rounded-full mt-2 flex-shrink-0"
                              style={{ width: '0.5rem', height: '0.5rem', backgroundColor: '#c084fc', borderRadius: '9999px', marginTop: '0.5rem', flexShrink: 0 }}
                            />
                            <span 
                              className="text-gray-700 text-sm"
                              style={{ 
                                color: '#374151', 
                                fontSize: '0.875rem',
                                wordWrap: 'break-word',
                                overflowWrap: 'break-word',
                                whiteSpace: 'normal',
                                overflow: 'visible'
                              }}
                            >
                              {achievement}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Projects */}
        {data.projects.length > 0 && (
          <div 
            className={`bg-white rounded-lg p-6 ${!isPDFMode ? 'shadow-sm' : ''}`}
            style={{ backgroundColor: '#ffffff', borderRadius: '0.5rem', padding: '1.5rem' }}
          >
            <h2 
              className="text-xl font-bold text-purple-600 mb-6 text-center"
              style={{ fontSize: '1.25rem', fontWeight: '700', color: '#9333ea', marginBottom: '1.5rem', textAlign: 'center' }}
            >
              Projects
            </h2>
            <div className="space-y-6" style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
              {data.projects.map((project) => (
                <div key={project.id} className="text-center" style={{ textAlign: 'center' }}>
                  <h3 
                    className="font-bold text-gray-900 text-lg"
                    style={{ fontWeight: '700', color: '#111827', fontSize: '1.125rem', textAlign: 'center' }}
                  >
                    {project.name}
                  </h3>
                  <div 
                    className="flex items-center justify-center gap-3 mt-2"
                    style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '0.75rem', marginTop: '0.5rem' }}
                  >
                    {project.url && (
                      <span 
                        className="bg-green-100 text-green-700 px-2 py-1 rounded text-xs flex items-center gap-1"
                        style={{ backgroundColor: '#dcfce7', color: '#15803d', padding: '0.25rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                      >
                        {!isPDFMode && <ExternalLink className="h-3 w-3" />}
                        <span>{isPDFMode ? '🔗 ' : ''}Live Demo</span>
                      </span>
                    )}
                    {project.githubUrl && (
                      <span 
                        className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs flex items-center gap-1"
                        style={{ backgroundColor: '#f3f4f6', color: '#374151', padding: '0.25rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.25rem' }}
                      >
                        {!isPDFMode && <Github className="h-3 w-3" />}
                        <span>{isPDFMode ? '💻 ' : ''}Code</span>
                      </span>
                    )}
                  </div>
                  <span 
                    className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs inline-block mt-2"
                    style={{ backgroundColor: '#dbeafe', color: '#1d4ed8', padding: '0.25rem 0.75rem', borderRadius: '9999px', fontSize: '0.75rem', display: 'inline-block', marginTop: '0.5rem' }}
                  >
                    {formatDate(project.startDate)} - {project.current ? 'Now' : formatDate(project.endDate)}
                  </span>
                  {project.description && (
                    <p 
                      className="text-gray-700 mt-3 mb-3 max-w-3xl mx-auto leading-relaxed"
                      style={{ 
                        color: '#374151', 
                        marginTop: '0.75rem', 
                        marginBottom: '0.75rem', 
                        maxWidth: isPDFMode ? 'none' : '48rem', 
                        marginLeft: 'auto', 
                        marginRight: 'auto', 
                        lineHeight: '1.625',
                        textAlign: 'center',
                        wordWrap: 'break-word',
                        overflowWrap: 'break-word',
                        whiteSpace: 'normal',
                        overflow: 'visible'
                      }}
                    >
                      {project.description}
                    </p>
                  )}
                  {project.technologies.length > 0 && (
                    <div 
                      className="flex flex-wrap justify-center gap-1 mb-3"
                      style={{ display: 'flex', flexWrap: 'wrap', justifyContent: 'center', gap: '0.25rem', marginBottom: '0.75rem' }}
                    >
                      {project.technologies.filter(t => t.trim()).map((tech, index) => (
                        <span 
                          key={index} 
                          className="bg-purple-100 text-purple-700 px-2 py-1 rounded text-xs"
                          style={{ backgroundColor: '#ede9fe', color: '#7c3aed', padding: '0.25rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.75rem' }}
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  )}
                  {project.achievements.length > 0 && (
                    <div 
                      className="max-w-3xl mx-auto mt-3"
                      style={{ 
                        maxWidth: isPDFMode ? 'none' : '48rem', 
                        marginLeft: 'auto', 
                        marginRight: 'auto', 
                        marginTop: '0.75rem',
                        width: isPDFMode ? '100%' : 'auto',
                        overflow: 'visible'
                      }}
                    >
                      <ul 
                        className="space-y-2 text-left"
                        style={{ 
                          display: 'flex', 
                          flexDirection: 'column', 
                          gap: '0.5rem', 
                          textAlign: 'left',
                          overflow: 'visible',
                          wordWrap: 'break-word',
                          overflowWrap: 'break-word'
                        }}
                      >
                        {project.achievements.filter(a => a.trim()).map((achievement, index) => (
                          <li 
                            key={index} 
                            className="flex items-start gap-2 justify-center"
                            style={{ display: 'flex', alignItems: 'flex-start', gap: '0.5rem', justifyContent: 'center' }}
                          >
                            <div 
                              className="w-2 h-2 bg-blue-400 rounded-full mt-2 flex-shrink-0"
                              style={{ width: '0.5rem', height: '0.5rem', backgroundColor: '#60a5fa', borderRadius: '9999px', marginTop: '0.5rem', flexShrink: 0 }}
                            />
                            <span 
                              className="text-gray-700 text-sm"
                              style={{ 
                                color: '#374151', 
                                fontSize: '0.875rem',
                                wordWrap: 'break-word',
                                overflowWrap: 'break-word',
                                whiteSpace: 'normal',
                                overflow: 'visible'
                              }}
                            >
                              {achievement}
                            </span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education */}
        {data.education.length > 0 && (
          <div 
            className={`bg-white rounded-lg p-6 ${!isPDFMode ? 'shadow-sm' : ''}`}
            style={{ backgroundColor: '#ffffff', borderRadius: '0.5rem', padding: '1.5rem' }}
          >
            <h2 
              className="text-xl font-bold text-purple-600 mb-6 text-center"
              style={{ fontSize: '1.25rem', fontWeight: '700', color: '#9333ea', marginBottom: '1.5rem', textAlign: 'center' }}
            >
              Education
            </h2>
            <div className="space-y-4" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {data.education.map((edu) => (
                <div key={edu.id} className="text-center" style={{ textAlign: 'center' }}>
                  <h3 
                    className="font-bold text-gray-900 text-lg"
                    style={{ fontWeight: '700', color: '#111827', fontSize: '1.125rem', textAlign: 'center' }}
                  >
                    {edu.degree} {edu.field && `in ${edu.field}`}
                  </h3>
                  <p 
                    className="text-purple-600 font-medium"
                    style={{ color: '#9333ea', fontWeight: '500', textAlign: 'center' }}
                  >
                    {edu.institution}
                  </p>
                  <span 
                    className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs inline-block mt-2"
                    style={{ backgroundColor: '#dbeafe', color: '#1d4ed8', padding: '0.25rem 0.75rem', borderRadius: '9999px', fontSize: '0.75rem', display: 'inline-block', marginTop: '0.5rem' }}
                  >
                    {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                  </span>
                  {edu.honors && (
                    <span 
                      className="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-xs block mt-2"
                      style={{ backgroundColor: '#fef3c7', color: '#a16207', padding: '0.25rem 0.5rem', borderRadius: '0.25rem', fontSize: '0.75rem', display: 'block', marginTop: '0.5rem' }}
                    >
                      {edu.honors}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Certifications */}
        {data.certifications.length > 0 && (
          <div 
            className={`bg-white rounded-lg p-6 ${!isPDFMode ? 'shadow-sm' : ''}`}
            style={{ backgroundColor: '#ffffff', borderRadius: '0.5rem', padding: '1.5rem' }}
          >
            <h2 
              className="text-xl font-bold text-purple-600 mb-6 text-center"
              style={{ fontSize: '1.25rem', fontWeight: '700', color: '#9333ea', marginBottom: '1.5rem', textAlign: 'center' }}
            >
              Certifications
            </h2>
            <div className="space-y-4" style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {data.certifications.map((cert) => (
                <div 
                  key={cert.id} 
                  className="text-center border-l-4 border-purple-300 pl-4 py-2"
                  style={{ textAlign: 'center', borderLeft: '4px solid #d8b4fe', paddingLeft: '1rem', paddingTop: '0.5rem', paddingBottom: '0.5rem' }}
                >
                  <h4 
                    className="font-semibold text-gray-900"
                    style={{ fontWeight: '600', color: '#111827' }}
                  >
                    {cert.name}
                  </h4>
                  <p 
                    className="text-sm text-purple-600"
                    style={{ fontSize: '0.875rem', color: '#9333ea' }}
                  >
                    {cert.issuer}
                  </p>
                  <p 
                    className="text-xs text-gray-600"
                    style={{ fontSize: '0.75rem', color: '#4b5563' }}
                  >
                    {formatDate(cert.dateObtained)}
                  </p>
                  {cert.credentialId && (
                    <p 
                      className="text-xs text-gray-600"
                      style={{ fontSize: '0.75rem', color: '#4b5563' }}
                    >
                      ID: {cert.credentialId}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Skills */}
        <div className="grid grid-cols-1 gap-6" style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '1.5rem' }}>
          {data.skills.technical.length > 0 && (
            <div 
              className={`bg-white rounded-lg p-6 ${!isPDFMode ? 'shadow-sm' : ''} text-center`}
              style={{ backgroundColor: '#ffffff', borderRadius: '0.5rem', padding: '1.5rem', textAlign: 'center' }}
            >
              <h2 
                className="text-lg font-bold text-purple-600 mb-4"
                style={{ fontSize: '1.125rem', fontWeight: '700', color: '#9333ea', marginBottom: '1rem' }}
              >
                Technical Skills
              </h2>
              <div 
                className="flex flex-wrap justify-center gap-2"
                style={{ 
                  display: 'flex', 
                  flexWrap: 'wrap', 
                  justifyContent: 'center', 
                  gap: '0.5rem',
                  overflow: 'visible',
                  width: isPDFMode ? '100%' : 'auto'
                }}
              >
                {data.skills.technical.map((skill, index) => (
                  <div 
                    key={index} 
                    className="bg-gradient-to-r from-purple-100 to-blue-100 px-3 py-2 rounded-lg"
                    style={{ 
                      background: 'linear-gradient(to right, #ede9fe, #dbeafe)', 
                      padding: '0.5rem 0.75rem', 
                      borderRadius: '0.5rem',
                      wordWrap: 'break-word',
                      overflow: 'visible'
                    }}
                  >
                    <span 
                      className="text-purple-700 font-medium"
                      style={{ color: '#7c3aed', fontWeight: '500' }}
                    >
                      {skill}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {data.skills.soft.length > 0 && (
            <div 
              className={`bg-white rounded-lg p-6 ${!isPDFMode ? 'shadow-sm' : ''} text-center`}
              style={{ backgroundColor: '#ffffff', borderRadius: '0.5rem', padding: '1.5rem', textAlign: 'center' }}
            >
              <h2 
                className="text-lg font-bold text-purple-600 mb-4"
                style={{ fontSize: '1.125rem', fontWeight: '700', color: '#9333ea', marginBottom: '1rem' }}
              >
                Soft Skills
              </h2>
              <div 
                className="flex flex-wrap justify-center gap-2"
                style={{ 
                  display: 'flex', 
                  flexWrap: 'wrap', 
                  justifyContent: 'center', 
                  gap: '0.5rem',
                  overflow: 'visible',
                  width: isPDFMode ? '100%' : 'auto'
                }}
              >
                {data.skills.soft.map((skill, index) => (
                  <span 
                    key={index} 
                    className="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-sm"
                    style={{ 
                      backgroundColor: '#dbeafe', 
                      color: '#1d4ed8', 
                      padding: '0.25rem 0.5rem', 
                      borderRadius: '9999px', 
                      fontSize: '0.875rem',
                      wordWrap: 'break-word',
                      overflow: 'visible'
                    }}
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          )}

          {data.skills.languages.length > 0 && (
            <div 
              className={`bg-white rounded-lg p-6 ${!isPDFMode ? 'shadow-sm' : ''} text-center`}
              style={{ backgroundColor: '#ffffff', borderRadius: '0.5rem', padding: '1.5rem', textAlign: 'center' }}
            >
              <h2 
                className="text-lg font-bold text-purple-600 mb-4"
                style={{ fontSize: '1.125rem', fontWeight: '700', color: '#9333ea', marginBottom: '1rem' }}
              >
                Languages
              </h2>
              <div 
                className="space-y-1"
                style={{ display: 'flex', flexDirection: 'column', gap: '0.25rem' }}
              >
                {data.skills.languages.map((language, index) => (
                  <div 
                    key={index} 
                    className="text-gray-700"
                    style={{ color: '#374151' }}
                  >
                    • {language}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  if (!data.personalInfo.fullName) {
    return (
      <div className="bg-gray-50 p-8 rounded-lg text-center">
        <p className="text-muted-foreground">Start filling out your information to see the preview</p>
      </div>
    );
  }

  switch (template) {
    case 'classic':
      return <ClassicTemplate />;
    case 'creative':
      return <CreativeTemplate />;
    case 'modern':
    default:
      return <ModernTemplate />;
  }
}