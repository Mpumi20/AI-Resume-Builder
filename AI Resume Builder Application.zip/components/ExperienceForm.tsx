import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Sparkles, ArrowRight, ArrowLeft, Plus, Trash2, Briefcase } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import type { ResumeData } from '../App';

interface ExperienceFormProps {
  data: ResumeData['experience'];
  onChange: (data: ResumeData['experience']) => void;
  onNext: () => void;
  onPrev: () => void;
  isAuthenticated?: boolean;
  accessToken?: string;
}

export function ExperienceForm({ data, onChange, onNext, onPrev, isAuthenticated, accessToken }: ExperienceFormProps) {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [optimizingIndex, setOptimizingIndex] = useState<number | null>(null);

  const addExperience = () => {
    const newExperience = {
      id: crypto.randomUUID(),
      company: '',
      position: '',
      startDate: '',
      endDate: '',
      current: false,
      description: '',
      achievements: [],
    };
    onChange([...data, newExperience]);
    setEditingIndex(data.length);
  };

  const updateExperience = (index: number, field: string, value: any) => {
    const updated = [...data];
    updated[index] = { ...updated[index], [field]: value };
    onChange(updated);
  };

  const removeExperience = (index: number) => {
    const updated = data.filter((_, i) => i !== index);
    onChange(updated);
    setEditingIndex(null);
  };

  const generateAchievements = async (index: number) => {
    const experience = data[index];
    
    if (isAuthenticated && accessToken && experience.position) {
      setOptimizingIndex(index);
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/ai/optimize-achievements`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            achievements: experience.achievements.length > 0 ? experience.achievements : [
              'Contributed to team projects',
              'Collaborated with colleagues',
              'Completed assigned tasks'
            ],
            position: experience.position
          }),
        });

        const result = await response.json();
        if (response.ok && result.optimizedAchievements) {
          updateExperience(index, 'achievements', result.optimizedAchievements);
        } else {
          throw new Error(result.error || 'Failed to optimize achievements');
        }
      } catch (error) {
        console.log('Error optimizing achievements:', error);
        // Fallback to local generation
        generateLocalAchievements(index);
      } finally {
        setOptimizingIndex(null);
      }
    } else {
      generateLocalAchievements(index);
    }
  };

  const generateLocalAchievements = (index: number) => {
    const position = data[index]?.position.toLowerCase() || '';
    const achievements = [];
    
    if (position.includes('engineer') || position.includes('developer')) {
      achievements.push(
        "Developed and maintained scalable web applications serving 10,000+ users",
        "Reduced application load time by 40% through code optimization",
        "Led technical design decisions and mentored 3 junior developers"
      );
    } else if (position.includes('manager')) {
      achievements.push(
        "Managed cross-functional team of 8 members, improving productivity by 25%",
        "Implemented new project management processes reducing delivery time by 30%",
        "Successfully delivered $2M+ projects on time and under budget"
      );
    } else if (position.includes('analyst')) {
      achievements.push(
        "Analyzed complex datasets resulting in $500K cost savings annually",
        "Created automated reporting dashboards reducing manual work by 60%",
        "Presented insights to C-level executives driving strategic decisions"
      );
    } else {
      achievements.push(
        "Exceeded performance targets by 20% for two consecutive quarters",
        "Collaborated with stakeholders to improve operational efficiency by 25%",
        "Implemented best practices that increased team productivity by 30%"
      );
    }

    updateExperience(index, 'achievements', achievements);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Briefcase className="h-5 w-5" />
            Work Experience
          </div>
          <Button onClick={addExperience} size="sm" className="flex items-center gap-1">
            <Plus className="h-4 w-4" />
            Add Experience
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {data.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Briefcase className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No work experience added yet.</p>
            <p className="text-sm">Click "Add Experience" to get started.</p>
          </div>
        ) : (
          data.map((experience, index) => (
            <Card key={experience.id} className="border-l-4 border-l-primary/20">
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4>{experience.position || 'Position Title'}</h4>
                      {experience.current && (
                        <Badge variant="secondary" className="text-xs bg-green-100 text-green-700 border-green-200">
                          Currently Working
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {experience.company || 'Company Name'}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setEditingIndex(editingIndex === index ? null : index)}
                    >
                      {editingIndex === index ? 'Collapse' : 'Edit'}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => removeExperience(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              {editingIndex === index && (
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Position Title *</Label>
                      <Input
                        value={experience.position}
                        onChange={(e) => updateExperience(index, 'position', e.target.value)}
                        placeholder="Software Engineer"
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Company *</Label>
                      <Input
                        value={experience.company}
                        onChange={(e) => updateExperience(index, 'company', e.target.value)}
                        placeholder="Tech Company Inc."
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Start Date *</Label>
                      <Input
                        type="month"
                        value={experience.startDate}
                        onChange={(e) => updateExperience(index, 'startDate', e.target.value)}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>End Date</Label>
                      <Input
                        type="month"
                        value={experience.endDate}
                        onChange={(e) => updateExperience(index, 'endDate', e.target.value)}
                        disabled={experience.current}
                      />
                      <div className="flex items-center space-x-2 mt-2">
                        <div 
                          className={`w-4 h-4 border-2 rounded cursor-pointer transition-all duration-200 flex items-center justify-center ${
                            experience.current 
                              ? 'bg-primary border-primary text-primary-foreground' 
                              : 'border-border bg-background hover:border-primary/50'
                          }`}
                          onClick={() => {
                            const newValue = !experience.current;
                            updateExperience(index, 'current', newValue);
                            if (newValue) {
                              updateExperience(index, 'endDate', '');
                            }
                          }}
                        >
                          {experience.current && (
                            <svg 
                              className="w-3 h-3" 
                              fill="currentColor" 
                              viewBox="0 0 20 20"
                            >
                              <path 
                                fillRule="evenodd" 
                                d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" 
                                clipRule="evenodd" 
                              />
                            </svg>
                          )}
                        </div>
                        <Label 
                          className={`text-sm cursor-pointer select-none transition-colors hover:text-primary ${experience.current ? 'text-green-700 font-medium' : ''}`}
                          onClick={() => {
                            const newValue = !experience.current;
                            updateExperience(index, 'current', newValue);
                            if (newValue) {
                              updateExperience(index, 'endDate', '');
                            }
                          }}
                        >
                          I currently work here
                        </Label>
                        {experience.current && (
                          <Badge variant="outline" className="text-xs text-green-700 border-green-300">
                            Active
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label>Job Description</Label>
                    <Textarea
                      value={experience.description}
                      onChange={(e) => updateExperience(index, 'description', e.target.value)}
                      placeholder="Describe your role and responsibilities..."
                      rows={3}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <Label>Key Achievements</Label>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => generateAchievements(index)}
                        disabled={optimizingIndex === index}
                        className="flex items-center gap-1"
                      >
                        <Sparkles className="h-3 w-3" />
                        {optimizingIndex === index ? 'Optimizing...' : isAuthenticated ? 'AI Optimize' : 'AI Generate'}
                      </Button>
                    </div>
                    <div className="space-y-2">
                      {experience.achievements.map((achievement, achIndex) => (
                        <div key={achIndex} className="flex items-center gap-2">
                          <span className="text-xs">•</span>
                          <Input
                            value={achievement}
                            onChange={(e) => {
                              const newAchievements = [...experience.achievements];
                              newAchievements[achIndex] = e.target.value;
                              updateExperience(index, 'achievements', newAchievements);
                            }}
                            placeholder="Quantifiable achievement or impact..."
                          />
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              const newAchievements = experience.achievements.filter((_, i) => i !== achIndex);
                              updateExperience(index, 'achievements', newAchievements);
                            }}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      ))}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          const newAchievements = [...experience.achievements, ''];
                          updateExperience(index, 'achievements', newAchievements);
                        }}
                        className="w-full"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Achievement
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Tip: Use action verbs and quantify your impact (e.g., "Increased sales by 25%")
                      {isAuthenticated && (
                        <span className="text-primary"> AI optimization available for signed-in users.</span>
                      )}
                    </p>
                  </div>
                </CardContent>
              )}
            </Card>
          ))
        )}
        
        <div className="flex justify-between pt-4">
          <Button variant="outline" onClick={onPrev} className="flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" />
            Previous
          </Button>
          <Button 
            onClick={onNext} 
            disabled={data.length === 0}
            className="flex items-center gap-2"
          >
            Next: Education
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}