import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Plus, X, ChevronRight, ChevronLeft, Code, Users, Globe } from 'lucide-react';

interface Skills {
  technical: string[];
  soft: string[];
  languages: string[];
}

interface SkillsFormProps {
  data: Skills;
  onChange: (data: Skills) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function SkillsForm({ data, onChange, onNext, onPrev }: SkillsFormProps) {
  const [newSkill, setNewSkill] = useState({ technical: '', soft: '', languages: '' });

  const addSkill = (category: keyof Skills) => {
    const skill = newSkill[category].trim();
    if (skill && !data[category].includes(skill)) {
      onChange({
        ...data,
        [category]: [...data[category], skill],
      });
      setNewSkill(prev => ({ ...prev, [category]: '' }));
    }
  };

  const removeSkill = (category: keyof Skills, index: number) => {
    onChange({
      ...data,
      [category]: data[category].filter((_, i) => i !== index),
    });
  };

  const handleKeyPress = (e: React.KeyboardEvent, category: keyof Skills) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addSkill(category);
    }
  };

  const suggestedSkills = {
    technical: [
      'JavaScript', 'TypeScript', 'Python', 'Java', 'React', 'Node.js', 'SQL', 'Git',
      'AWS', 'Docker', 'Kubernetes', 'MongoDB', 'PostgreSQL', 'Redis', 'GraphQL',
      'Vue.js', 'Angular', 'Spring Boot', 'Django', 'Flask', 'Express.js'
    ],
    soft: [
      'Leadership', 'Communication', 'Problem Solving', 'Team Collaboration', 'Time Management',
      'Critical Thinking', 'Adaptability', 'Creativity', 'Project Management', 'Strategic Planning',
      'Conflict Resolution', 'Mentoring', 'Decision Making', 'Analytical Thinking'
    ],
    languages: [
      'English', 'Spanish', 'French', 'German', 'Chinese (Mandarin)', 'Japanese', 'Korean',
      'Portuguese', 'Italian', 'Russian', 'Arabic', 'Hindi', 'Dutch', 'Swedish'
    ]
  };

  const addSuggestedSkill = (category: keyof Skills, skill: string) => {
    if (!data[category].includes(skill)) {
      onChange({
        ...data,
        [category]: [...data[category], skill],
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Skills & Competencies</CardTitle>
        <p className="text-sm text-muted-foreground">
          Add your technical skills, soft skills, and languages to showcase your capabilities.
        </p>
      </CardHeader>
      <CardContent className="space-y-8">
        {/* Technical Skills */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Code className="h-5 w-5 text-blue-600" />
            <Label className="font-medium">Technical Skills</Label>
          </div>
          
          <div className="space-y-3">
            <div className="flex gap-2">
              <Input
                value={newSkill.technical}
                onChange={(e) => setNewSkill(prev => ({ ...prev, technical: e.target.value }))}
                onKeyPress={(e) => handleKeyPress(e, 'technical')}
                placeholder="e.g., JavaScript, React, Python..."
                className="flex-1"
              />
              <Button
                type="button"
                onClick={() => addSkill('technical')}
                size="sm"
                className="flex items-center gap-1"
              >
                <Plus className="h-4 w-4" />
                Add
              </Button>
            </div>
            
            {data.technical.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {data.technical.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {skill}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSkill('technical', index)}
                      className="h-auto p-0 hover:bg-transparent"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
            
            {/* Suggested Technical Skills */}
            <div>
              <p className="text-sm text-muted-foreground mb-2">Suggested technical skills:</p>
              <div className="flex flex-wrap gap-1">
                {suggestedSkills.technical
                  .filter(skill => !data.technical.includes(skill))
                  .slice(0, 8)
                  .map((skill) => (
                    <Button
                      key={skill}
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => addSuggestedSkill('technical', skill)}
                      className="h-7 text-xs"
                    >
                      {skill}
                    </Button>
                  ))}
              </div>
            </div>
          </div>
        </div>

        <Separator />

        {/* Soft Skills */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Users className="h-5 w-5 text-green-600" />
            <Label className="font-medium">Soft Skills & Core Competencies</Label>
          </div>
          
          <div className="space-y-3">
            <div className="flex gap-2">
              <Input
                value={newSkill.soft}
                onChange={(e) => setNewSkill(prev => ({ ...prev, soft: e.target.value }))}
                onKeyPress={(e) => handleKeyPress(e, 'soft')}
                placeholder="e.g., Leadership, Communication, Problem Solving..."
                className="flex-1"
              />
              <Button
                type="button"
                onClick={() => addSkill('soft')}
                size="sm"
                className="flex items-center gap-1"
              >
                <Plus className="h-4 w-4" />
                Add
              </Button>
            </div>
            
            {data.soft.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {data.soft.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {skill}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSkill('soft', index)}
                      className="h-auto p-0 hover:bg-transparent"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
            
            {/* Suggested Soft Skills */}
            <div>
              <p className="text-sm text-muted-foreground mb-2">Suggested soft skills:</p>
              <div className="flex flex-wrap gap-1">
                {suggestedSkills.soft
                  .filter(skill => !data.soft.includes(skill))
                  .slice(0, 8)
                  .map((skill) => (
                    <Button
                      key={skill}
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => addSuggestedSkill('soft', skill)}
                      className="h-7 text-xs"
                    >
                      {skill}
                    </Button>
                  ))}
              </div>
            </div>
          </div>
        </div>

        <Separator />

        {/* Languages */}
        <div>
          <div className="flex items-center gap-2 mb-4">
            <Globe className="h-5 w-5 text-purple-600" />
            <Label className="font-medium">Languages</Label>
          </div>
          
          <div className="space-y-3">
            <div className="flex gap-2">
              <Input
                value={newSkill.languages}
                onChange={(e) => setNewSkill(prev => ({ ...prev, languages: e.target.value }))}
                onKeyPress={(e) => handleKeyPress(e, 'languages')}
                placeholder="e.g., English (Native), Spanish (Fluent)..."
                className="flex-1"
              />
              <Button
                type="button"
                onClick={() => addSkill('languages')}
                size="sm"
                className="flex items-center gap-1"
              >
                <Plus className="h-4 w-4" />
                Add
              </Button>
            </div>
            
            {data.languages.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {data.languages.map((language, index) => (
                  <Badge key={index} variant="secondary" className="flex items-center gap-1">
                    {language}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeSkill('languages', index)}
                      className="h-auto p-0 hover:bg-transparent"
                    >
                      <X className="h-3 w-3" />
                    </Button>
                  </Badge>
                ))}
              </div>
            )}
            
            {/* Suggested Languages */}
            <div>
              <p className="text-sm text-muted-foreground mb-2">Suggested languages:</p>
              <div className="flex flex-wrap gap-1">
                {suggestedSkills.languages
                  .filter(language => !data.languages.includes(language))
                  .slice(0, 8)
                  .map((language) => (
                    <Button
                      key={language}
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => addSuggestedSkill('languages', language)}
                      className="h-7 text-xs"
                    >
                      {language}
                    </Button>
                  ))}
              </div>
            </div>
          </div>
        </div>

        {/* Skill Level Tips */}
        <div className="bg-muted/50 rounded-lg p-4">
          <h4 className="font-medium mb-2">💡 Pro Tips for Skills</h4>
          <ul className="space-y-1 text-sm text-muted-foreground">
            <li>• Be specific with technical skills (e.g., "React.js" instead of "Frontend")</li>
            <li>• Include proficiency levels for languages (e.g., "Spanish (Fluent)")</li>
            <li>• Focus on skills relevant to your target role</li>
            <li>• Keep the list concise but comprehensive</li>
          </ul>
        </div>

        {/* Navigation Buttons */}
        <div className="flex justify-between pt-6 border-t">
          <Button variant="outline" onClick={onPrev} className="flex items-center gap-2">
            <ChevronLeft className="h-4 w-4" />
            Certifications
          </Button>
          <Button onClick={onNext} className="flex items-center gap-2">
            Preview & Export
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}