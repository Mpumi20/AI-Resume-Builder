import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Plus, Trash2, ExternalLink, Github, Calendar, ChevronRight, ChevronLeft } from 'lucide-react';

interface Project {
  id: string;
  name: string;
  description: string;
  technologies: string[];
  startDate: string;
  endDate: string;
  current: boolean;
  url?: string;
  githubUrl?: string;
  achievements: string[];
}

interface ProjectsFormProps {
  data: Project[];
  onChange: (data: Project[]) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function ProjectsForm({ data, onChange, onNext, onPrev }: ProjectsFormProps) {
  const [expandedProject, setExpandedProject] = useState<string | null>(null);

  const addProject = () => {
    const newProject: Project = {
      id: crypto.randomUUID(),
      name: '',
      description: '',
      technologies: [],
      startDate: '',
      endDate: '',
      current: false,
      url: '',
      githubUrl: '',
      achievements: [''],
    };
    onChange([...data, newProject]);
    setExpandedProject(newProject.id);
  };

  const updateProject = (id: string, field: keyof Project, value: any) => {
    onChange(data.map(project => 
      project.id === id ? { ...project, [field]: value } : project
    ));
  };

  const removeProject = (id: string) => {
    onChange(data.filter(project => project.id !== id));
    if (expandedProject === id) {
      setExpandedProject(null);
    }
  };

  const addTechnology = (projectId: string) => {
    const project = data.find(p => p.id === projectId);
    if (project) {
      updateProject(projectId, 'technologies', [...project.technologies, '']);
    }
  };

  const updateTechnology = (projectId: string, index: number, value: string) => {
    const project = data.find(p => p.id === projectId);
    if (project) {
      const newTechnologies = [...project.technologies];
      newTechnologies[index] = value;
      updateProject(projectId, 'technologies', newTechnologies);
    }
  };

  const removeTechnology = (projectId: string, index: number) => {
    const project = data.find(p => p.id === projectId);
    if (project) {
      updateProject(projectId, 'technologies', project.technologies.filter((_, i) => i !== index));
    }
  };

  const addAchievement = (projectId: string) => {
    const project = data.find(p => p.id === projectId);
    if (project) {
      updateProject(projectId, 'achievements', [...project.achievements, '']);
    }
  };

  const updateAchievement = (projectId: string, index: number, value: string) => {
    const project = data.find(p => p.id === projectId);
    if (project) {
      const newAchievements = [...project.achievements];
      newAchievements[index] = value;
      updateProject(projectId, 'achievements', newAchievements);
    }
  };

  const removeAchievement = (projectId: string, index: number) => {
    const project = data.find(p => p.id === projectId);
    if (project) {
      updateProject(projectId, 'achievements', project.achievements.filter((_, i) => i !== index));
    }
  };

  const formatDateForInput = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    if (isNaN(date.getTime())) return '';
    return date.toISOString().split('T')[0];
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Projects</CardTitle>
        <p className="text-sm text-muted-foreground">
          Showcase your personal and professional projects to demonstrate your skills and experience.
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {data.length === 0 ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground mb-4">No projects added yet</p>
            <Button onClick={addProject} className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Add Your First Project
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {data.map((project, index) => (
              <Card key={project.id} className="border-l-4 border-l-blue-500">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="font-medium">
                        {project.name || `Project ${index + 1}`}
                      </h3>
                      {project.technologies.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {project.technologies.filter(tech => tech.trim()).slice(0, 3).map((tech, i) => (
                            <Badge key={i} variant="secondary" className="text-xs">
                              {tech}
                            </Badge>
                          ))}
                          {project.technologies.filter(tech => tech.trim()).length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{project.technologies.filter(tech => tech.trim()).length - 3} more
                            </Badge>
                          )}
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedProject(
                          expandedProject === project.id ? null : project.id
                        )}
                      >
                        {expandedProject === project.id ? 'Collapse' : 'Edit'}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeProject(project.id)}
                        className="text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {expandedProject === project.id && (
                  <CardContent className="space-y-4">
                    {/* Basic Information */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor={`project-name-${project.id}`}>Project Name *</Label>
                        <Input
                          id={`project-name-${project.id}`}
                          value={project.name}
                          onChange={(e) => updateProject(project.id, 'name', e.target.value)}
                          placeholder="e.g., E-commerce Platform"
                        />
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <div 
                          className={`w-8 h-5 rounded-full border-2 cursor-pointer transition-all duration-300 relative ${
                            project.current 
                              ? 'bg-primary border-primary' 
                              : 'bg-switch-background border-border hover:border-primary/50'
                          }`}
                          onClick={() => {
                            const newValue = !project.current;
                            updateProject(project.id, 'current', newValue);
                            if (newValue) {
                              updateProject(project.id, 'endDate', '');
                            }
                          }}
                        >
                          <div 
                            className={`w-4 h-4 bg-white rounded-full shadow-sm transition-transform duration-300 absolute top-0.5 ${
                              project.current 
                                ? 'translate-x-3' 
                                : 'translate-x-0.5'
                            }`}
                          />
                        </div>
                        <Label 
                          className="cursor-pointer select-none transition-colors hover:text-primary"
                          onClick={() => {
                            const newValue = !project.current;
                            updateProject(project.id, 'current', newValue);
                            if (newValue) {
                              updateProject(project.id, 'endDate', '');
                            }
                          }}
                        >
                          Currently working on this project
                        </Label>
                        {project.current && (
                          <Badge variant="outline" className="text-xs text-green-700 border-green-300">
                            Active
                          </Badge>
                        )}
                      </div>
                    </div>

                    {/* Description */}
                    <div>
                      <Label htmlFor={`project-description-${project.id}`}>Description</Label>
                      <Textarea
                        id={`project-description-${project.id}`}
                        value={project.description}
                        onChange={(e) => updateProject(project.id, 'description', e.target.value)}
                        placeholder="Brief description of the project and your role..."
                        className="min-h-20"
                      />
                    </div>

                    {/* Dates */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor={`start-date-${project.id}`}>Start Date</Label>
                        <Input
                          id={`start-date-${project.id}`}
                          type="date"
                          value={formatDateForInput(project.startDate)}
                          onChange={(e) => updateProject(project.id, 'startDate', e.target.value)}
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor={`end-date-${project.id}`}>
                          {project.current ? 'Expected End Date' : 'End Date'}
                        </Label>
                        <Input
                          id={`end-date-${project.id}`}
                          type="date"
                          value={formatDateForInput(project.endDate)}
                          onChange={(e) => updateProject(project.id, 'endDate', e.target.value)}
                          disabled={project.current}
                        />
                      </div>
                    </div>

                    {/* URLs */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor={`project-url-${project.id}`} className="flex items-center gap-1">
                          <ExternalLink className="h-3 w-3" />
                          Project URL
                        </Label>
                        <Input
                          id={`project-url-${project.id}`}
                          value={project.url || ''}
                          onChange={(e) => updateProject(project.id, 'url', e.target.value)}
                          placeholder="https://yourproject.com"
                          type="url"
                        />
                      </div>
                      
                      <div>
                        <Label htmlFor={`github-url-${project.id}`} className="flex items-center gap-1">
                          <Github className="h-3 w-3" />
                          GitHub URL
                        </Label>
                        <Input
                          id={`github-url-${project.id}`}
                          value={project.githubUrl || ''}
                          onChange={(e) => updateProject(project.id, 'githubUrl', e.target.value)}
                          placeholder="https://github.com/yourusername/project"
                          type="url"
                        />
                      </div>
                    </div>

                    <Separator />

                    {/* Technologies */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <Label>Technologies Used</Label>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => addTechnology(project.id)}
                          className="flex items-center gap-1"
                        >
                          <Plus className="h-3 w-3" />
                          Add Technology
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {project.technologies.map((technology, techIndex) => (
                          <div key={techIndex} className="flex gap-2">
                            <Input
                              value={technology}
                              onChange={(e) => updateTechnology(project.id, techIndex, e.target.value)}
                              placeholder="e.g., React, Node.js, MongoDB"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removeTechnology(project.id, techIndex)}
                              className="px-2"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>

                    <Separator />

                    {/* Key Achievements */}
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <Label>Key Achievements & Features</Label>
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => addAchievement(project.id)}
                          className="flex items-center gap-1"
                        >
                          <Plus className="h-3 w-3" />
                          Add Achievement
                        </Button>
                      </div>
                      <div className="space-y-2">
                        {project.achievements.map((achievement, achievementIndex) => (
                          <div key={achievementIndex} className="flex gap-2">
                            <Input
                              value={achievement}
                              onChange={(e) => updateAchievement(project.id, achievementIndex, e.target.value)}
                              placeholder="e.g., Implemented user authentication with 99.9% uptime"
                            />
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removeAchievement(project.id, achievementIndex)}
                              className="px-2"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}

            <Button
              variant="outline"
              onClick={addProject}
              className="w-full flex items-center gap-2"
            >
              <Plus className="h-4 w-4" />
              Add Another Project
            </Button>
          </div>
        )}

        {/* Navigation Buttons */}
        <div className="flex justify-between pt-6 border-t">
          <Button variant="outline" onClick={onPrev} className="flex items-center gap-2">
            <ChevronLeft className="h-4 w-4" />
            Education
          </Button>
          <Button onClick={onNext} className="flex items-center gap-2">
            Certifications
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}