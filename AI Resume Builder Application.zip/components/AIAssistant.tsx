import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Sparkles, X, Lightbulb, Target, TrendingUp, MessageSquare } from 'lucide-react';
import type { ResumeData } from '../App';

interface AIAssistantProps {
  resumeData: ResumeData;
  onSuggestionApply: (suggestion: any) => void;
  onClose: () => void;
}

export function AIAssistant({ resumeData, onSuggestionApply, onClose }: AIAssistantProps) {
  const [activeTab, setActiveTab] = useState('suggestions');
  const [jobDescription, setJobDescription] = useState('');
  const [analysisResults, setAnalysisResults] = useState<any>(null);

  const contentSuggestions = [
    {
      type: 'summary',
      title: 'Enhance Your Summary',
      suggestion: 'Add quantifiable achievements to your professional summary. For example: "Experienced software engineer with 5+ years developing scalable applications serving 100k+ users."',
      impact: 'High',
    },
    {
      type: 'experience',
      title: 'Quantify Achievements',
      suggestion: 'Transform "Improved system performance" to "Improved system performance by 40%, reducing load times from 3s to 1.8s"',
      impact: 'High',
    },
    {
      type: 'skills',
      title: 'Add Trending Skills',
      suggestion: 'Consider adding these in-demand skills: React, TypeScript, Cloud Computing, API Development',
      impact: 'Medium',
    },
    {
      type: 'keywords',
      title: 'Industry Keywords',
      suggestion: 'Include more industry-specific keywords like "agile development", "cross-functional collaboration", "stakeholder management"',
      impact: 'Medium',
    },
  ];

  const optimizationTips = [
    {
      icon: Target,
      title: 'Keyword Optimization',
      description: 'Your resume contains 12 relevant keywords. Aim for 15-20 for better ATS compatibility.',
      action: 'Add more technical keywords',
    },
    {
      icon: TrendingUp,
      title: 'Impact Statements',
      description: '3 out of 5 bullet points include quantifiable results. Add numbers to remaining achievements.',
      action: 'Quantify achievements',
    },
    {
      icon: Lightbulb,
      title: 'Section Balance',
      description: 'Consider adding a "Projects" section to showcase practical applications of your skills.',
      action: 'Add projects section',
    },
  ];

  const analyzeJobMatch = () => {
    if (!jobDescription.trim()) return;

    // Simulate job description analysis
    const keywords = jobDescription.toLowerCase();
    const userSkills = resumeData.skills.technical.map(s => s.toLowerCase());
    
    const matchedSkills = userSkills.filter(skill => 
      keywords.includes(skill)
    );
    
    const missingSkills = [
      'Docker', 'Kubernetes', 'AWS', 'Microservices', 'GraphQL'
    ].filter(skill => 
      keywords.includes(skill.toLowerCase()) && 
      !userSkills.includes(skill.toLowerCase())
    );

    const suggestions = [
      'Emphasize experience with distributed systems',
      'Highlight leadership and mentoring experience',
      'Add examples of process improvement initiatives',
    ];

    setAnalysisResults({
      matchPercentage: Math.round((matchedSkills.length / (matchedSkills.length + missingSkills.length)) * 100),
      matchedSkills,
      missingSkills,
      suggestions,
    });
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="h-5 w-5" />
          AI Assistant
        </CardTitle>
        <Button variant="ghost" size="sm" onClick={onClose}>
          <X className="h-4 w-4" />
        </Button>
      </CardHeader>
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
            <TabsTrigger value="optimize">Optimize</TabsTrigger>
            <TabsTrigger value="match">Job Match</TabsTrigger>
          </TabsList>
          
          <TabsContent value="suggestions" className="space-y-4">
            <div className="space-y-3">
              {contentSuggestions.map((suggestion, index) => (
                <Card key={index} className="border-l-4 border-l-blue-500">
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-medium">{suggestion.title}</h4>
                      <Badge 
                        variant={suggestion.impact === 'High' ? 'default' : 'secondary'}
                        className="text-xs"
                      >
                        {suggestion.impact} Impact
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-3">
                      {suggestion.suggestion}
                    </p>
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => onSuggestionApply(suggestion)}
                    >
                      Apply Suggestion
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="optimize" className="space-y-4">
            <div className="space-y-4">
              {optimizationTips.map((tip, index) => {
                const Icon = tip.icon;
                return (
                  <div key={index} className="flex items-start gap-3 p-4 border rounded-lg">
                    <Icon className="h-5 w-5 text-primary mt-1" />
                    <div className="flex-1">
                      <h4 className="font-medium mb-1">{tip.title}</h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        {tip.description}
                      </p>
                      <Button size="sm" variant="outline">
                        {tip.action}
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          </TabsContent>
          
          <TabsContent value="match" className="space-y-4">
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Paste Job Description
                </label>
                <Textarea
                  placeholder="Paste the job description here to get AI-powered matching analysis..."
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  rows={6}
                />
                <Button 
                  className="mt-3" 
                  onClick={analyzeJobMatch}
                  disabled={!jobDescription.trim()}
                >
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Analyze Match
                </Button>
              </div>
              
              {analysisResults && (
                <Card>
                  <CardContent className="pt-4">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">Match Score</span>
                        <Badge 
                          variant={analysisResults.matchPercentage >= 70 ? 'default' : 'secondary'}
                          className="text-lg px-3 py-1"
                        >
                          {analysisResults.matchPercentage}%
                        </Badge>
                      </div>
                      
                      {analysisResults.matchedSkills.length > 0 && (
                        <div>
                          <h4 className="font-medium text-green-600 mb-2">Matched Skills</h4>
                          <div className="flex flex-wrap gap-1">
                            {analysisResults.matchedSkills.map((skill: string, index: number) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      {analysisResults.missingSkills.length > 0 && (
                        <div>
                          <h4 className="font-medium text-orange-600 mb-2">Skills to Add</h4>
                          <div className="flex flex-wrap gap-1">
                            {analysisResults.missingSkills.map((skill: string, index: number) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                      
                      <div>
                        <h4 className="font-medium mb-2">AI Recommendations</h4>
                        <ul className="space-y-1">
                          {analysisResults.suggestions.map((suggestion: string, index: number) => (
                            <li key={index} className="text-sm text-muted-foreground">
                              • {suggestion}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}