import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Alert, AlertDescription } from './ui/alert';
import { Download, FileText, Globe, CheckCircle, AlertCircle, Zap } from 'lucide-react';
import { ResumePreview } from './ResumePreview';
import { exportToPDF } from '../utils/pdfExport';
import { exportToWord } from '../utils/wordExport';
import type { ResumeData } from '../App';

interface ExportOptionsProps {
  resumeData: ResumeData;
  template: 'modern' | 'classic' | 'creative';
  isAuthenticated?: boolean;
  accessToken?: string;
}

export function ExportOptions({ resumeData, template, isAuthenticated, accessToken }: ExportOptionsProps) {
  const [exportType, setExportType] = useState<'pdf' | 'docx' | 'html'>('pdf');
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const printRef = useRef<HTMLDivElement>(null);
  const [atsAnalysis, setAtsAnalysis] = useState({
    score: 85,
    issues: [
      'Consider adding more industry keywords',
      'Include quantifiable achievements',
    ],
    strengths: [
      'Clear contact information',
      'Professional summary included',
      'Relevant work experience',
      'Skills section well-organized',
    ],
  });

  const exportFormats = [
    {
      type: 'pdf' as const,
      icon: FileText,
      name: 'PDF',
      description: 'Best for most applications',
      recommended: true,
    },
    {
      type: 'docx' as const,
      icon: FileText,
      name: 'Word Document',
      description: 'Editable format for customization',
      recommended: false,
    },
    {
      type: 'html' as const,
      icon: Globe,
      name: 'HTML',
      description: 'For online portfolios',
      recommended: false,
    },
  ];

  const generatePDF = async () => {
    try {
      setExportProgress(5);

      // Use the centralized PDF export utility that supports templates
      await exportToPDF({
        resumeData,
        template,
        onProgress: setExportProgress,
      });

      setExportProgress(100);
    } catch (error) {
      console.error('PDF generation error:', error);
      throw new Error('Failed to generate PDF. Please try again.');
    }
  };

  const generateDOCX = async () => {
    try {
      // Use the centralized Word export utility that supports templates and prevents cutoff
      await exportToWord({
        resumeData,
        template,
        onProgress: setExportProgress,
      });
    } catch (error) {
      console.error('DOCX generation error:', error);
      throw new Error('Failed to generate Word document. Please try again.');
    }
  };

  const generateHTML = () => {
    const formatDate = (dateString: string) => {
      if (!dateString) return '';
      try {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
      } catch {
        return dateString;
      }
    };

    const generateTemplateHTML = () => {
      if (template === 'modern') {
        return `
          <div class="resume-container modern-template">
            <!-- Header -->
            <div class="header">
              <h1 class="name">${resumeData.personalInfo.fullName || 'Your Name'}</h1>
              <div class="contact-info">
                ${resumeData.personalInfo.email ? `<div class="contact-item"><span class="icon">📧</span> ${resumeData.personalInfo.email}</div>` : ''}
                ${resumeData.personalInfo.phone ? `<div class="contact-item"><span class="icon">📞</span> ${resumeData.personalInfo.phone}</div>` : ''}
                ${resumeData.personalInfo.location ? `<div class="contact-item"><span class="icon">📍</span> ${resumeData.personalInfo.location}</div>` : ''}
                ${resumeData.personalInfo.linkedIn ? `<div class="contact-item"><span class="icon">🔗</span> ${resumeData.personalInfo.linkedIn}</div>` : ''}
                ${resumeData.personalInfo.website ? `<div class="contact-item"><span class="icon">🌐</span> ${resumeData.personalInfo.website}</div>` : ''}
              </div>
            </div>

            ${resumeData.personalInfo.summary ? `
              <div class="section">
                <h2 class="section-title">Professional Summary</h2>
                <p class="summary">${resumeData.personalInfo.summary}</p>
              </div>
            ` : ''}

            ${resumeData.experience.length > 0 ? `
              <div class="section">
                <h2 class="section-title">Experience</h2>
                ${resumeData.experience.map(exp => `
                  <div class="item">
                    <div class="item-header">
                      <div class="item-left">
                        <h3 class="item-title">${exp.position}</h3>
                        <p class="item-subtitle">${exp.company}</p>
                      </div>
                      <div class="item-date">
                        <span class="date-icon">📅</span>
                        ${formatDate(exp.startDate)} - ${exp.current ? 'Present' : formatDate(exp.endDate)}
                      </div>
                    </div>
                    ${exp.description ? `<p class="item-description">${exp.description}</p>` : ''}
                    ${exp.achievements.length > 0 ? `
                      <ul class="achievements">
                        ${exp.achievements.filter(a => a.trim()).map(achievement => `
                          <li>${achievement}</li>
                        `).join('')}
                      </ul>
                    ` : ''}
                  </div>
                `).join('')}
              </div>
            ` : ''}

            ${resumeData.projects && resumeData.projects.length > 0 ? `
              <div class="section">
                <h2 class="section-title">Projects</h2>
                ${resumeData.projects.map(project => `
                  <div class="item">
                    <div class="item-header">
                      <div class="item-left">
                        <h3 class="item-title">${project.name}</h3>
                        ${project.url || project.githubUrl ? `
                          <div class="project-links">
                            ${project.url ? `<span class="project-link">🔗 Demo</span>` : ''}
                            ${project.githubUrl ? `<span class="project-link">💻 Code</span>` : ''}
                          </div>
                        ` : ''}
                      </div>
                      <div class="item-date">
                        <span class="date-icon">📅</span>
                        ${formatDate(project.startDate)} - ${project.current ? 'Present' : formatDate(project.endDate)}
                      </div>
                    </div>
                    ${project.description ? `<p class="item-description">${project.description}</p>` : ''}
                    ${project.technologies.length > 0 ? `
                      <div class="tech-tags">
                        ${project.technologies.filter(t => t.trim()).map(tech => `
                          <span class="tech-tag">${tech}</span>
                        `).join('')}
                      </div>
                    ` : ''}
                    ${project.achievements.length > 0 ? `
                      <ul class="achievements">
                        ${project.achievements.filter(a => a.trim()).map(achievement => `
                          <li>${achievement}</li>
                        `).join('')}
                      </ul>
                    ` : ''}
                  </div>
                `).join('')}
              </div>
            ` : ''}

            ${resumeData.education.length > 0 ? `
              <div class="section">
                <h2 class="section-title">Education</h2>
                ${resumeData.education.map(edu => `
                  <div class="item">
                    <div class="item-header">
                      <div class="item-left">
                        <h3 class="item-title">${edu.degree} ${edu.field ? `in ${edu.field}` : ''}</h3>
                        <p class="item-subtitle">${edu.institution}</p>
                        ${edu.honors ? `<p class="honors">${edu.honors}</p>` : ''}
                      </div>
                      <div class="item-date">
                        <span class="date-icon">📅</span>
                        ${formatDate(edu.startDate)} - ${formatDate(edu.endDate)}
                      </div>
                    </div>
                  </div>
                `).join('')}
              </div>
            ` : ''}

            ${resumeData.certifications && resumeData.certifications.length > 0 ? `
              <div class="section">
                <h2 class="section-title">Certifications</h2>
                ${resumeData.certifications.map(cert => `
                  <div class="item">
                    <div class="item-header">
                      <div class="item-left">
                        <h3 class="item-title">${cert.name}</h3>
                        <p class="item-subtitle">${cert.issuer}</p>
                        ${cert.credentialId ? `<p class="credential-id">ID: ${cert.credentialId}</p>` : ''}
                      </div>
                      <div class="item-date">
                        <span class="date-icon">🏆</span>
                        ${formatDate(cert.dateObtained)}
                        ${cert.expiryDate ? ` - ${formatDate(cert.expiryDate)}` : ''}
                      </div>
                    </div>
                  </div>
                `).join('')}
              </div>
            ` : ''}

            <!-- Skills Grid -->
            <div class="skills-grid">
              ${resumeData.skills.technical.length > 0 ? `
                <div class="skills-section">
                  <h2 class="section-title">Technical Skills</h2>
                  <div class="skill-tags">
                    ${resumeData.skills.technical.map(skill => `
                      <span class="skill-tag primary">${skill}</span>
                    `).join('')}
                  </div>
                </div>
              ` : ''}

              ${resumeData.skills.soft.length > 0 ? `
                <div class="skills-section">
                  <h2 class="section-title">Core Competencies</h2>
                  <div class="skill-tags">
                    ${resumeData.skills.soft.map(skill => `
                      <span class="skill-tag secondary">${skill}</span>
                    `).join('')}
                  </div>
                </div>
              ` : ''}

              ${resumeData.skills.languages.length > 0 ? `
                <div class="skills-section">
                  <h2 class="section-title">Languages</h2>
                  <div class="skill-tags">
                    ${resumeData.skills.languages.map(language => `
                      <span class="skill-tag success">${language}</span>
                    `).join('')}
                  </div>
                </div>
              ` : ''}
            </div>
          </div>
        `;
      } else if (template === 'classic') {
        return `
          <div class="resume-container classic-template">
            <!-- Header -->
            <div class="header">
              <h1 class="name">${resumeData.personalInfo.fullName || 'Your Name'}</h1>
              <div class="contact-info">
                ${resumeData.personalInfo.email ? `<div>${resumeData.personalInfo.email}</div>` : ''}
                ${resumeData.personalInfo.phone ? `<div>${resumeData.personalInfo.phone}</div>` : ''}
                ${resumeData.personalInfo.location ? `<div>${resumeData.personalInfo.location}</div>` : ''}
                ${resumeData.personalInfo.linkedIn ? `<div>${resumeData.personalInfo.linkedIn}</div>` : ''}
              </div>
            </div>

            ${resumeData.personalInfo.summary ? `
              <div class="section">
                <h2 class="section-title">PROFESSIONAL SUMMARY</h2>
                <p class="summary">${resumeData.personalInfo.summary}</p>
              </div>
            ` : ''}

            ${resumeData.experience.length > 0 ? `
              <div class="section">
                <h2 class="section-title">PROFESSIONAL EXPERIENCE</h2>
                ${resumeData.experience.map(exp => `
                  <div class="item">
                    <div class="item-header">
                      <h3 class="item-title">${exp.position}</h3>
                      <span class="item-date">${formatDate(exp.startDate)} - ${exp.current ? 'Present' : formatDate(exp.endDate)}</span>
                    </div>
                    <p class="company">${exp.company}</p>
                    ${exp.description ? `<p class="item-description">${exp.description}</p>` : ''}
                    ${exp.achievements.length > 0 ? `
                      <ul class="achievements">
                        ${exp.achievements.filter(a => a.trim()).map(achievement => `
                          <li>${achievement}</li>
                        `).join('')}
                      </ul>
                    ` : ''}
                  </div>
                `).join('')}
              </div>
            ` : ''}

            ${resumeData.projects && resumeData.projects.length > 0 ? `
              <div class="section">
                <h2 class="section-title">PROJECTS</h2>
                ${resumeData.projects.map(project => `
                  <div class="item">
                    <div class="item-header">
                      <h3 class="item-title">${project.name}</h3>
                      <span class="item-date">${formatDate(project.startDate)} - ${project.current ? 'Present' : formatDate(project.endDate)}</span>
                    </div>
                    ${project.description ? `<p class="item-description">${project.description}</p>` : ''}
                    ${project.technologies.length > 0 ? `
                      <p class="technologies"><strong>Technologies:</strong> ${project.technologies.filter(t => t.trim()).join(', ')}</p>
                    ` : ''}
                    ${project.achievements.length > 0 ? `
                      <ul class="achievements">
                        ${project.achievements.filter(a => a.trim()).map(achievement => `
                          <li>${achievement}</li>
                        `).join('')}
                      </ul>
                    ` : ''}
                  </div>
                `).join('')}
              </div>
            ` : ''}

            ${resumeData.education.length > 0 ? `
              <div class="section">
                <h2 class="section-title">EDUCATION</h2>
                ${resumeData.education.map(edu => `
                  <div class="item">
                    <div class="item-header">
                      <h3 class="item-title">${edu.degree} ${edu.field ? `in ${edu.field}` : ''}</h3>
                      <span class="item-date">${formatDate(edu.startDate)} - ${formatDate(edu.endDate)}</span>
                    </div>
                    <p class="company">${edu.institution}</p>
                    ${edu.honors ? `<p class="honors">${edu.honors}</p>` : ''}
                  </div>
                `).join('')}
              </div>
            ` : ''}

            ${resumeData.certifications && resumeData.certifications.length > 0 ? `
              <div class="section">
                <h2 class="section-title">CERTIFICATIONS</h2>
                ${resumeData.certifications.map(cert => `
                  <div class="item">
                    <div class="item-header">
                      <h3 class="item-title">${cert.name}</h3>
                      <span class="item-date">${formatDate(cert.dateObtained)}</span>
                    </div>
                    <p class="company">${cert.issuer}</p>
                    ${cert.credentialId ? `<p class="credential-id">ID: ${cert.credentialId}</p>` : ''}
                  </div>
                `).join('')}
              </div>
            ` : ''}

            ${(resumeData.skills.technical.length > 0 || resumeData.skills.soft.length > 0) ? `
              <div class="section">
                <h2 class="section-title">SKILLS</h2>
                ${resumeData.skills.technical.length > 0 ? `
                  <div class="skill-category">
                    <p class="skill-category-title">Technical:</p>
                    <p class="skill-list">${resumeData.skills.technical.join(', ')}</p>
                  </div>
                ` : ''}
                ${resumeData.skills.soft.length > 0 ? `
                  <div class="skill-category">
                    <p class="skill-category-title">Core Competencies:</p>
                    <p class="skill-list">${resumeData.skills.soft.join(', ')}</p>
                  </div>
                ` : ''}
                ${resumeData.skills.languages.length > 0 ? `
                  <div class="skill-category">
                    <p class="skill-category-title">Languages:</p>
                    <p class="skill-list">${resumeData.skills.languages.join(', ')}</p>
                  </div>
                ` : ''}
              </div>
            ` : ''}
          </div>
        `;
      } else if (template === 'creative') {
        return `
          <div class="resume-container creative-template">
            <!-- Header -->
            <div class="header">
              <h1 class="name">${resumeData.personalInfo.fullName || 'Your Name'}</h1>
              <div class="contact-info">
                ${resumeData.personalInfo.email ? `<div class="contact-item">📧 ${resumeData.personalInfo.email}</div>` : ''}
                ${resumeData.personalInfo.phone ? `<div class="contact-item">📞 ${resumeData.personalInfo.phone}</div>` : ''}
                ${resumeData.personalInfo.location ? `<div class="contact-item">📍 ${resumeData.personalInfo.location}</div>` : ''}
                ${resumeData.personalInfo.linkedIn ? `<div class="contact-item">🔗 ${resumeData.personalInfo.linkedIn}</div>` : ''}
              </div>
            </div>

            ${resumeData.personalInfo.summary ? `
              <div class="summary-card">
                <h2 class="section-title">About Me</h2>
                <p class="summary">${resumeData.personalInfo.summary}</p>
              </div>
            ` : ''}

            <div class="main-grid">
              <!-- Left Column -->
              <div class="left-column">
                ${resumeData.experience.length > 0 ? `
                  <div class="section-card">
                    <h2 class="section-title">Experience</h2>
                    ${resumeData.experience.map(exp => `
                      <div class="item">
                        <div class="item-header">
                          <div class="item-left">
                            <h3 class="item-title">${exp.position}</h3>
                            <p class="item-subtitle">${exp.company}</p>
                          </div>
                          <span class="date-badge">${formatDate(exp.startDate)} - ${exp.current ? 'Now' : formatDate(exp.endDate)}</span>
                        </div>
                        ${exp.description ? `<p class="item-description">${exp.description}</p>` : ''}
                        ${exp.achievements.length > 0 ? `
                          <ul class="bullet-list">
                            ${exp.achievements.filter(a => a.trim()).map(achievement => `
                              <li><span class="bullet"></span>${achievement}</li>
                            `).join('')}
                          </ul>
                        ` : ''}
                      </div>
                    `).join('')}
                  </div>
                ` : ''}

                ${resumeData.projects && resumeData.projects.length > 0 ? `
                  <div class="section-card">
                    <h2 class="section-title">Projects</h2>
                    ${resumeData.projects.map(project => `
                      <div class="item">
                        <div class="item-header">
                          <div class="item-left">
                            <h3 class="item-title">${project.name}</h3>
                            ${project.url || project.githubUrl ? `
                              <div class="project-badges">
                                ${project.url ? `<span class="project-badge demo">🔗 Live Demo</span>` : ''}
                                ${project.githubUrl ? `<span class="project-badge code">💻 Code</span>` : ''}
                              </div>
                            ` : ''}
                          </div>
                          <span class="date-badge secondary">${formatDate(project.startDate)} - ${project.current ? 'Now' : formatDate(project.endDate)}</span>
                        </div>
                        ${project.description ? `<p class="item-description">${project.description}</p>` : ''}
                        ${project.technologies.length > 0 ? `
                          <div class="tech-badges">
                            ${project.technologies.filter(t => t.trim()).map(tech => `
                              <span class="tech-badge">${tech}</span>
                            `).join('')}
                          </div>
                        ` : ''}
                        ${project.achievements.length > 0 ? `
                          <ul class="bullet-list">
                            ${project.achievements.filter(a => a.trim()).map(achievement => `
                              <li><span class="bullet secondary"></span>${achievement}</li>
                            `).join('')}
                          </ul>
                        ` : ''}
                      </div>
                    `).join('')}
                  </div>
                ` : ''}

                ${resumeData.education.length > 0 ? `
                  <div class="section-card">
                    <h2 class="section-title">Education</h2>
                    ${resumeData.education.map(edu => `
                      <div class="item">
                        <div class="item-header">
                          <div class="item-left">
                            <h3 class="item-title">${edu.degree} ${edu.field ? `in ${edu.field}` : ''}</h3>
                            <p class="item-subtitle">${edu.institution}</p>
                            ${edu.honors ? `<span class="honor-badge">${edu.honors}</span>` : ''}
                          </div>
                          <span class="date-badge secondary">${formatDate(edu.startDate)} - ${formatDate(edu.endDate)}</span>
                        </div>
                      </div>
                    `).join('')}
                  </div>
                ` : ''}
              </div>

              <!-- Right Column -->
              <div class="right-column">
                ${resumeData.skills.technical.length > 0 ? `
                  <div class="section-card">
                    <h2 class="section-title">Technical Skills</h2>
                    <div class="skill-grid">
                      ${resumeData.skills.technical.map(skill => `
                        <div class="skill-card">${skill}</div>
                      `).join('')}
                    </div>
                  </div>
                ` : ''}

                ${resumeData.skills.soft.length > 0 ? `
                  <div class="section-card">
                    <h2 class="section-title">Soft Skills</h2>
                    <div class="skill-tags">
                      ${resumeData.skills.soft.map(skill => `
                        <span class="skill-tag">${skill}</span>
                      `).join('')}
                    </div>
                  </div>
                ` : ''}

                ${resumeData.certifications && resumeData.certifications.length > 0 ? `
                  <div class="section-card">
                    <h2 class="section-title">Certifications</h2>
                    ${resumeData.certifications.map(cert => `
                      <div class="cert-item">
                        <h4 class="cert-title">${cert.name}</h4>
                        <p class="cert-issuer">${cert.issuer}</p>
                        <p class="cert-date">${formatDate(cert.dateObtained)}</p>
                      </div>
                    `).join('')}
                  </div>
                ` : ''}

                ${resumeData.skills.languages.length > 0 ? `
                  <div class="section-card">
                    <h2 class="section-title">Languages</h2>
                    <div class="language-list">
                      ${resumeData.skills.languages.map(language => `
                        <div class="language-item">• ${language}</div>
                      `).join('')}
                    </div>
                  </div>
                ` : ''}
              </div>
            </div>
          </div>
        `;
      }
      
      return '<div>Template not found</div>';
    };

    const getTemplateCSS = () => {
      const baseCSS = `
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
          line-height: 1.6;
          color: #333;
          background: #f8f9fa;
          padding: 20px;
        }
        
        .resume-container {
          max-width: 800px;
          margin: 0 auto;
          background: white;
          border-radius: 8px;
          box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
          overflow: hidden;
        }
        
        @media print {
          body {
            background: white;
            padding: 0;
          }
          .resume-container {
            box-shadow: none;
            border-radius: 0;
          }
        }
      `;

      if (template === 'modern') {
        return baseCSS + `
          .modern-template {
            padding: 40px;
          }
          
          .header {
            border-bottom: 2px solid #2563eb;
            padding-bottom: 24px;
            margin-bottom: 32px;
          }
          
          .name {
            font-size: 2.5rem;
            font-weight: 600;
            color: #111827;
            margin-bottom: 12px;
          }
          
          .contact-info {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            color: #4b5563;
            font-size: 0.9rem;
          }
          
          .contact-item {
            display: flex;
            align-items: center;
            gap: 6px;
          }
          
          .icon {
            font-size: 0.8rem;
          }
          
          .section {
            margin-bottom: 32px;
          }
          
          .section-title {
            font-size: 1.5rem;
            font-weight: 600;
            color: #2563eb;
            margin-bottom: 20px;
          }
          
          .summary {
            color: #374151;
            font-size: 1rem;
            line-height: 1.7;
          }
          
          .item {
            margin-bottom: 24px;
            padding-bottom: 20px;
            border-bottom: 1px solid #f3f4f6;
          }
          
          .item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
          }
          
          .item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
          }
          
          .item-title {
            font-size: 1.2rem;
            font-weight: 600;
            color: #111827;
            margin-bottom: 4px;
          }
          
          .item-subtitle {
            color: #2563eb;
            font-weight: 500;
            font-size: 1rem;
          }
          
          .item-date {
            font-size: 0.9rem;
            color: #4b5563;
            display: flex;
            align-items: center;
            gap: 4px;
            white-space: nowrap;
          }
          
          .date-icon {
            font-size: 0.8rem;
          }
          
          .item-description {
            color: #374151;
            margin-bottom: 12px;
            font-size: 0.95rem;
          }
          
          .achievements {
            list-style: none;
            margin-left: 0;
          }
          
          .achievements li {
            position: relative;
            padding-left: 20px;
            margin-bottom: 8px;
            color: #374151;
            font-size: 0.9rem;
          }
          
          .achievements li::before {
            content: "•";
            position: absolute;
            left: 0;
            color: #2563eb;
            font-weight: bold;
          }
          
          .project-links {
            display: flex;
            gap: 12px;
            margin-top: 4px;
          }
          
          .project-link {
            font-size: 0.8rem;
            color: #2563eb;
          }
          
          .tech-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 12px 0;
          }
          
          .tech-tag {
            background: #f3f4f6;
            color: #374151;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
          }
          
          .honors, .credential-id {
            font-size: 0.85rem;
            color: #4b5563;
            margin-top: 4px;
          }
          
          .skills-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 24px;
          }
          
          .skills-section .section-title {
            font-size: 1.3rem;
            margin-bottom: 16px;
          }
          
          .skill-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
          }
          
          .skill-tag {
            padding: 6px 16px;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
          }
          
          .skill-tag.primary {
            background: #dbeafe;
            color: #1d4ed8;
          }
          
          .skill-tag.secondary {
            background: #f3f4f6;
            color: #374151;
          }
          
          .skill-tag.success {
            background: #dcfce7;
            color: #166534;
          }
          
          @media (max-width: 768px) {
            .modern-template {
              padding: 24px;
            }
            
            .name {
              font-size: 2rem;
            }
            
            .contact-info {
              flex-direction: column;
              gap: 8px;
            }
            
            .item-header {
              flex-direction: column;
              align-items: flex-start;
            }
            
            .item-date {
              margin-top: 8px;
            }
            
            .skills-grid {
              grid-template-columns: 1fr;
            }
          }
        `;
      } else if (template === 'classic') {
        return baseCSS + `
          .classic-template {
            padding: 40px;
          }
          
          .header {
            text-align: center;
            border-bottom: 1px solid #ddd;
            padding-bottom: 24px;
            margin-bottom: 32px;
          }
          
          .name {
            font-size: 2rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 16px;
          }
          
          .contact-info {
            color: #666;
            line-height: 1.5;
            font-size: 0.9rem;
          }
          
          .contact-info div {
            margin-bottom: 4px;
          }
          
          .section {
            margin-bottom: 32px;
          }
          
          .section-title {
            font-size: 1.3rem;
            font-weight: 600;
            color: #111;
            border-bottom: 1px solid #ddd;
            padding-bottom: 8px;
            margin-bottom: 20px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
          }
          
          .summary {
            color: #444;
            font-size: 1rem;
            line-height: 1.7;
          }
          
          .item {
            margin-bottom: 24px;
          }
          
          .item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 8px;
          }
          
          .item-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #111;
          }
          
          .item-date {
            font-size: 0.9rem;
            color: #666;
            white-space: nowrap;
          }
          
          .company {
            font-weight: 500;
            color: #444;
            margin-bottom: 8px;
          }
          
          .item-description {
            color: #444;
            margin-bottom: 12px;
            font-size: 0.95rem;
          }
          
          .achievements {
            list-style-type: disc;
            margin-left: 20px;
          }
          
          .achievements li {
            margin-bottom: 4px;
            color: #444;
            font-size: 0.9rem;
          }
          
          .technologies {
            font-size: 0.9rem;
            color: #666;
            margin-bottom: 12px;
          }
          
          .honors, .credential-id {
            font-size: 0.85rem;
            color: #666;
            margin-top: 4px;
          }
          
          .skill-category {
            margin-bottom: 16px;
          }
          
          .skill-category-title {
            font-weight: 500;
            color: #111;
            margin-bottom: 4px;
          }
          
          .skill-list {
            color: #444;
          }
          
          @media (max-width: 768px) {
            .classic-template {
              padding: 24px;
            }
            
            .name {
              font-size: 1.75rem;
            }
            
            .item-header {
              flex-direction: column;
              align-items: flex-start;
            }
            
            .item-date {
              margin-top: 4px;
            }
          }
        `;
      } else if (template === 'creative') {
        return baseCSS + `
          .creative-template {
            background: linear-gradient(135deg, #fdf4ff 0%, #eff6ff 100%);
            padding: 40px;
          }
          
          .header {
            background: linear-gradient(135deg, #9333ea 0%, #2563eb 100%);
            color: white;
            padding: 32px;
            border-radius: 12px;
            margin-bottom: 32px;
          }
          
          .name {
            font-size: 2.5rem;
            font-weight: 600;
            margin-bottom: 16px;
          }
          
          .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 8px;
            font-size: 0.9rem;
          }
          
          .contact-item {
            display: flex;
            align-items: center;
            gap: 8px;
          }
          
          .summary-card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            margin-bottom: 32px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          }
          
          .main-grid {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 32px;
          }
          
          .left-column, .right-column {
            display: flex;
            flex-direction: column;
            gap: 24px;
          }
          
          .section-card {
            background: white;
            border-radius: 12px;
            padding: 24px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
          }
          
          .section-title {
            font-size: 1.4rem;
            font-weight: 600;
            color: #9333ea;
            margin-bottom: 20px;
          }
          
          .summary {
            color: #374151;
            line-height: 1.7;
          }
          
          .item {
            margin-bottom: 24px;
            padding-bottom: 20px;
            border-bottom: 1px solid #f3f4f6;
          }
          
          .item:last-child {
            border-bottom: none;
            margin-bottom: 0;
            padding-bottom: 0;
          }
          
          .item-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 12px;
          }
          
          .item-title {
            font-size: 1.1rem;
            font-weight: 600;
            color: #111827;
            margin-bottom: 4px;
          }
          
          .item-subtitle {
            color: #9333ea;
            font-weight: 500;
          }
          
          .date-badge {
            background: #ede9fe;
            color: #7c3aed;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.8rem;
            white-space: nowrap;
          }
          
          .date-badge.secondary {
            background: #dbeafe;
            color: #1d4ed8;
          }
          
          .item-description {
            color: #374151;
            margin-bottom: 12px;
            font-size: 0.9rem;
          }
          
          .bullet-list {
            list-style: none;
            margin: 0;
          }
          
          .bullet-list li {
            display: flex;
            align-items: flex-start;
            gap: 8px;
            margin-bottom: 8px;
            color: #374151;
            font-size: 0.9rem;
          }
          
          .bullet {
            width: 8px;
            height: 8px;
            background: #9333ea;
            border-radius: 50%;
            margin-top: 6px;
            flex-shrink: 0;
          }
          
          .bullet.secondary {
            background: #2563eb;
          }
          
          .project-badges {
            display: flex;
            gap: 8px;
            margin-top: 4px;
          }
          
          .project-badge {
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
          }
          
          .project-badge.demo {
            background: #dcfce7;
            color: #166534;
          }
          
          .project-badge.code {
            background: #f3f4f6;
            color: #374151;
          }
          
          .tech-badges {
            display: flex;
            flex-wrap: wrap;
            gap: 4px;
            margin: 12px 0;
          }
          
          .tech-badge {
            background: #ede9fe;
            color: #7c3aed;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
          }
          
          .honor-badge {
            background: #fef3c7;
            color: #d97706;
            padding: 2px 8px;
            border-radius: 4px;
            font-size: 0.75rem;
            margin-top: 4px;
            display: inline-block;
          }
          
          .skill-grid {
            display: flex;
            flex-direction: column;
            gap: 8px;
          }
          
          .skill-card {
            background: linear-gradient(135deg, #ede9fe 0%, #dbeafe 100%);
            color: #7c3aed;
            padding: 12px;
            border-radius: 8px;
            font-weight: 500;
            text-align: center;
          }
          
          .skill-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
          }
          
          .skill-tag {
            background: #dbeafe;
            color: #1d4ed8;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
          }
          
          .cert-item {
            border-left: 4px solid #9333ea;
            padding-left: 12px;
            margin-bottom: 16px;
          }
          
          .cert-title {
            font-weight: 500;
            color: #111827;
            margin-bottom: 4px;
          }
          
          .cert-issuer {
            color: #9333ea;
            font-size: 0.9rem;
            margin-bottom: 4px;
          }
          
          .cert-date {
            color: #4b5563;
            font-size: 0.8rem;
          }
          
          .language-list {
            display: flex;
            flex-direction: column;
            gap: 4px;
          }
          
          .language-item {
            color: #374151;
            font-size: 0.9rem;
          }
          
          @media (max-width: 768px) {
            .creative-template {
              padding: 20px;
            }
            
            .header {
              padding: 24px;
            }
            
            .name {
              font-size: 2rem;
            }
            
            .contact-info {
              grid-template-columns: 1fr;
            }
            
            .main-grid {
              grid-template-columns: 1fr;
              gap: 24px;
            }
            
            .item-header {
              flex-direction: column;
              align-items: flex-start;
            }
            
            .date-badge {
              margin-top: 8px;
            }
          }
        `;
      }
      
      return baseCSS;
    };

    const htmlContent = `
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>${resumeData.personalInfo.fullName || 'Resume'} - ${template.charAt(0).toUpperCase() + template.slice(1)} Template</title>
    <style>
        ${getTemplateCSS()}
    </style>
</head>
<body>
    ${generateTemplateHTML()}
    
    <div style="text-align: center; margin-top: 40px; padding: 20px; color: #666; font-size: 0.8rem; border-top: 1px solid #eee;">
        <p>Generated with AI Resume Builder - ${template.charAt(0).toUpperCase() + template.slice(1)} Template</p>
        <p>Export Date: ${new Date().toLocaleDateString()}</p>
    </div>
</body>
</html>`;

    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const timestamp = new Date().toISOString().slice(0, 10);
    a.download = `${resumeData.personalInfo.fullName || 'resume'}_${template}_${timestamp}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleExport = async () => {
    setIsExporting(true);
    setExportProgress(0);
    
    try {
      switch (exportType) {
        case 'pdf':
          await generatePDF();
          break;
        case 'docx':
          await generateDOCX();
          break;
        case 'html':
          setExportProgress(50);
          generateHTML();
          setExportProgress(100);
          break;
      }
      
      // Reset progress after a brief delay
      setTimeout(() => {
        setExportProgress(0);
        setIsExporting(false);
      }, 1000);
      
    } catch (error) {
      console.error('Export error:', error);
      alert(error instanceof Error ? error.message : 'Export failed. Please try again.');
      setIsExporting(false);
      setExportProgress(0);
    }
  };

  const runATSCheck = () => {
    // Simulate ATS analysis
    const hasKeywords = resumeData.skills.technical.length > 3;
    const hasQuantifiableAchievements = resumeData.experience.some(exp => 
      exp.achievements.some(achievement => /\d+/.test(achievement))
    );
    const hasCompleteSections = resumeData.personalInfo.fullName && 
                                resumeData.experience.length > 0 && 
                                resumeData.education.length > 0;
    
    let score = 60;
    if (hasKeywords) score += 15;
    if (hasQuantifiableAchievements) score += 15;
    if (hasCompleteSections) score += 10;
    
    const issues = [];
    const strengths = ['Well-structured format', 'Clear section headers'];
    
    if (!hasKeywords) issues.push('Add more relevant technical keywords');
    if (!hasQuantifiableAchievements) issues.push('Include quantifiable achievements with numbers');
    if (resumeData.personalInfo.summary.length < 50) issues.push('Expand professional summary');
    
    if (hasKeywords) strengths.push('Good keyword density');
    if (hasQuantifiableAchievements) strengths.push('Quantifiable achievements included');
    if (resumeData.personalInfo.summary) strengths.push('Professional summary present');
    
    setAtsAnalysis({ score, issues, strengths });
  };

  React.useEffect(() => {
    runATSCheck();
  }, [resumeData]);

  return (
    <div className="space-y-6">
      {/* Hidden print container for PDF generation */}
      <div style={{ position: 'absolute', left: '-9999px', top: 0, visibility: 'hidden' }}>
        <div 
          ref={printRef} 
          style={{ 
            width: '210mm',
            minHeight: '297mm',
            backgroundColor: '#ffffff',
            color: '#000000',
            fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
            padding: '0',
            margin: '0',
            overflow: 'visible'
          }}
        >
          <ResumePreview data={resumeData} template={template} />
        </div>
      </div>

      {/* ATS Compatibility Check */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            ATS Compatibility Check
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <span>ATS Score</span>
            <Badge 
              variant={atsAnalysis.score >= 80 ? "default" : atsAnalysis.score >= 60 ? "secondary" : "destructive"}
              className="text-lg px-3 py-1"
            >
              {atsAnalysis.score}%
            </Badge>
          </div>
          
          <Progress value={atsAnalysis.score} className="w-full" />
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-medium text-green-600 mb-2 flex items-center gap-1">
                <CheckCircle className="h-4 w-4" />
                Strengths
              </h4>
              <ul className="space-y-1">
                {atsAnalysis.strengths.map((strength, index) => (
                  <li key={index} className="text-sm text-gray-600">• {strength}</li>
                ))}
              </ul>
            </div>
            
            <div>
              <h4 className="font-medium text-orange-600 mb-2 flex items-center gap-1">
                <AlertCircle className="h-4 w-4" />
                Recommendations
              </h4>
              <ul className="space-y-1">
                {atsAnalysis.issues.map((issue, index) => (
                  <li key={index} className="text-sm text-gray-600">• {issue}</li>
                ))}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Export Options */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Download className="h-5 w-5" />
            Export Resume - {template.charAt(0).toUpperCase() + template.slice(1)} Template
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>Template Selected:</strong> Your resume will be exported using the <strong>{template.charAt(0).toUpperCase() + template.slice(1)}</strong> template design. The exported file will match exactly what you see in the preview above.
            </AlertDescription>
          </Alert>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {exportFormats.map((format) => {
              const Icon = format.icon;
              return (
                <div
                  key={format.type}
                  className={`border rounded-lg p-4 cursor-pointer transition-all ${
                    exportType === format.type
                      ? 'border-primary ring-2 ring-primary/20'
                      : 'border-border hover:border-primary/50'
                  }`}
                  onClick={() => setExportType(format.type)}
                >
                  <div className="flex items-start gap-3">
                    <Icon className="h-5 w-5 text-primary mt-1" />
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{format.name}</h3>
                        {format.recommended && (
                          <Badge variant="secondary" className="text-xs">
                            Recommended
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        {format.description}
                      </p>
                      {format.type === 'pdf' && (
                        <p className="text-xs text-primary mt-1">
                          Will use {template} template design
                        </p>
                      )}
                      {format.type === 'html' && (
                        <p className="text-xs text-primary mt-1">
                          Complete {template} template with all sections
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              <strong>HTML Export:</strong> Creates a complete, standalone HTML file with all your resume information formatted according to your chosen template. Perfect for online portfolios and personal websites. Includes responsive design and print-friendly styles.
            </AlertDescription>
          </Alert>

          {/* Progress Bar */}
          {isExporting && exportProgress > 0 && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Generating {exportType.toUpperCase()} with {template} template...</span>
                <span>{exportProgress}%</span>
              </div>
              <Progress value={exportProgress} className="w-full" />
            </div>
          )}
          
          <Button
            onClick={handleExport}
            disabled={isExporting || !resumeData.personalInfo.fullName}
            className="w-full flex items-center gap-2"
            size="lg"
          >
            {isExporting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                Generating {exportType.toUpperCase()} with {template} template...
              </>
            ) : (
              <>
                <Download className="h-4 w-4" />
                Export as {exportType.toUpperCase()} ({template} template)
              </>
            )}
          </Button>
          
          <div className="text-xs text-muted-foreground text-center">
            Your data is processed locally and never sent to external servers. The exported file will maintain your selected template design with complete resume information.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}