import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Sparkles, ArrowRight, User } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import type { ResumeData } from '../App';

interface PersonalInfoFormProps {
  data: ResumeData['personalInfo'];
  onChange: (data: ResumeData['personalInfo']) => void;
  onNext: () => void;
  isAuthenticated?: boolean;
  accessToken?: string;
}

export function PersonalInfoForm({ data, onChange, onNext, isAuthenticated, accessToken }: PersonalInfoFormProps) {
  const [isGenerating, setIsGenerating] = useState(false);

  const handleChange = (field: keyof ResumeData['personalInfo'], value: string) => {
    onChange({
      ...data,
      [field]: value,
    });
  };

  const generateSummary = async () => {
    if (isAuthenticated && accessToken) {
      setIsGenerating(true);
      try {
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/ai/generate-summary`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            experience: [], // We'll enhance this with actual experience data
            skills: { technical: [], soft: [] },
            targetRole: 'Professional'
          }),
        });

        const result = await response.json();
        if (response.ok && result.summary) {
          handleChange('summary', result.summary);
        } else {
          throw new Error(result.error || 'Failed to generate summary');
        }
      } catch (error) {
        console.log('Error generating summary:', error);
        // Fallback to local generation
        generateLocalSummary();
      } finally {
        setIsGenerating(false);
      }
    } else {
      // Local generation for non-authenticated users
      generateLocalSummary();
    }
  };

  const generateLocalSummary = () => {
    const suggestions = [
      "Experienced professional with expertise in leadership and strategic thinking, passionate about driving results and creating value through innovative solutions.",
      "Results-driven professional with strong analytical skills and experience in cross-functional collaboration, committed to delivering high-quality outcomes.",
      "Detail-oriented professional with excellent communication skills and a track record of managing complex projects and building effective partnerships.",
      "Dynamic professional with expertise in problem-solving and process improvement, dedicated to achieving excellence and continuous professional development."
    ];
    
    const randomSuggestion = suggestions[Math.floor(Math.random() * suggestions.length)];
    handleChange('summary', randomSuggestion);
  };

  const isFormValid = data.fullName && data.email && data.phone;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <User className="h-5 w-5" />
          Personal Information
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="fullName">Full Name *</Label>
            <Input
              id="fullName"
              value={data.fullName}
              onChange={(e) => handleChange('fullName', e.target.value)}
              placeholder="John Doe"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              value={data.email}
              onChange={(e) => handleChange('email', e.target.value)}
              placeholder="john.doe@email.com"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="phone">Phone *</Label>
            <Input
              id="phone"
              value={data.phone}
              onChange={(e) => handleChange('phone', e.target.value)}
              placeholder="+1 (555) 123-4567"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="location">Location</Label>
            <Input
              id="location"
              value={data.location}
              onChange={(e) => handleChange('location', e.target.value)}
              placeholder="New York, NY"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="linkedIn">LinkedIn</Label>
            <Input
              id="linkedIn"
              value={data.linkedIn}
              onChange={(e) => handleChange('linkedIn', e.target.value)}
              placeholder="linkedin.com/in/johndoe"
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="website">Website/Portfolio</Label>
            <Input
              id="website"
              value={data.website}
              onChange={(e) => handleChange('website', e.target.value)}
              placeholder="johndoe.com"
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <Label htmlFor="summary">Professional Summary</Label>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={generateSummary}
              disabled={isGenerating}
              className="flex items-center gap-1"
            >
              <Sparkles className="h-3 w-3" />
              {isGenerating ? 'Generating...' : 'AI Generate'}
            </Button>
          </div>
          <Textarea
            id="summary"
            value={data.summary}
            onChange={(e) => handleChange('summary', e.target.value)}
            placeholder="Write a compelling summary that highlights your key strengths and career objectives..."
            rows={4}
          />
          <p className="text-xs text-muted-foreground">
            Tip: A strong summary should be 2-3 sentences highlighting your experience, skills, and career goals.
            {isAuthenticated && (
              <span className="text-primary"> AI generation available for signed-in users.</span>
            )}
          </p>
        </div>
        
        <div className="flex justify-end pt-4">
          <Button 
            onClick={onNext} 
            disabled={!isFormValid}
            className="flex items-center gap-2"
          >
            Next: Experience
            <ArrowRight className="h-4 w-4" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}