import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Palette, Check } from 'lucide-react';

interface TemplateSelectorProps {
  selectedTemplate: 'modern' | 'classic' | 'creative';
  onTemplateChange: (template: 'modern' | 'classic' | 'creative') => void;
}

const templates = [
  {
    id: 'modern' as const,
    name: 'Modern',
    description: 'Clean and professional with blue accents',
    features: ['ATS-friendly', 'Clean layout', 'Professional colors'],
    preview: 'bg-gradient-to-br from-blue-50 to-blue-100',
  },
  {
    id: 'classic' as const,
    name: 'Classic',
    description: 'Traditional black and white format',
    features: ['Timeless design', 'High readability', 'Conservative style'],
    preview: 'bg-gradient-to-br from-gray-50 to-gray-100',
  },
  {
    id: 'creative' as const,
    name: 'Creative',
    description: 'Eye-catching design with color gradients',
    features: ['Stand out design', 'Creative industries', 'Modern gradients'],
    preview: 'bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50',
  },
];

export function TemplateSelector({ selectedTemplate, onTemplateChange }: TemplateSelectorProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="h-5 w-5" />
          Choose Template
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {templates.map((template) => (
            <div
              key={template.id}
              className={`relative border rounded-lg p-4 cursor-pointer transition-all ${
                selectedTemplate === template.id
                  ? 'border-primary ring-2 ring-primary/20'
                  : 'border-border hover:border-primary/50'
              }`}
              onClick={() => onTemplateChange(template.id)}
            >
              {selectedTemplate === template.id && (
                <div className="absolute top-2 right-2 bg-primary text-primary-foreground rounded-full p-1">
                  <Check className="h-3 w-3" />
                </div>
              )}
              
              {/* Preview */}
              <div className={`${template.preview} h-32 rounded-md mb-3 border flex items-center justify-center`}>
                <div className="text-center">
                  <div className="bg-white/80 backdrop-blur-sm rounded px-3 py-1 text-sm font-medium">
                    {template.name} Preview
                  </div>
                </div>
              </div>
              
              {/* Template Info */}
              <div>
                <h3 className="font-semibold mb-1">{template.name}</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  {template.description}
                </p>
                
                <div className="space-y-1">
                  {template.features.map((feature, index) => (
                    <Badge key={index} variant="secondary" className="text-xs mr-1 mb-1">
                      {feature}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <Button
                variant={selectedTemplate === template.id ? "default" : "outline"}
                className="w-full mt-3"
                onClick={(e) => {
                  e.stopPropagation();
                  onTemplateChange(template.id);
                }}
              >
                {selectedTemplate === template.id ? 'Selected' : 'Select'}
              </Button>
            </div>
          ))}
        </div>
        
        <div className="mt-6 p-4 bg-muted rounded-lg">
          <h4 className="font-medium mb-2">Template Recommendations</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• <strong>Modern:</strong> Best for tech, finance, and corporate roles</li>
            <li>• <strong>Classic:</strong> Ideal for traditional industries and senior positions</li>
            <li>• <strong>Creative:</strong> Perfect for design, marketing, and creative fields</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}