import React, { useState, useEffect } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs';
import { Badge } from './components/ui/badge';
import { Progress } from './components/ui/progress';
import { PersonalInfoForm } from './components/PersonalInfoForm';
import { ExperienceForm } from './components/ExperienceForm';
import { EducationForm } from './components/EducationForm';
import { SkillsForm } from './components/SkillsForm';
import { ProjectsForm } from './components/ProjectsForm';
import { CertificationsForm } from './components/CertificationsForm';
import { ResumePreview } from './components/ResumePreview';
import { TemplateSelector } from './components/TemplateSelector';
import { AIAssistant } from './components/AIAssistant';
import { ExportOptions } from './components/ExportOptions';
import { AuthModal } from './components/AuthModal';
import { ResumeManager } from './components/ResumeManager';
import { Sparkles, Eye, Download, Shield, User, Save, Cloud, FileDown } from 'lucide-react';
import { getSupabaseClient } from './utils/supabase/client';
import { projectId, publicAnonKey } from './utils/supabase/info';
import { exportToPDF } from './utils/pdfExport';

export interface ResumeData {
  personalInfo: {
    fullName: string;
    email: string;
    phone: string;
    location: string;
    linkedIn: string;
    website: string;
    summary: string;
  };
  experience: Array<{
    id: string;
    company: string;
    position: string;
    startDate: string;
    endDate: string;
    current: boolean;
    description: string;
    achievements: string[];
  }>;
  education: Array<{
    id: string;
    institution: string;
    degree: string;
    field: string;
    startDate: string;
    endDate: string;
    gpa?: string;
    honors?: string;
  }>;
  projects: Array<{
    id: string;
    name: string;
    description: string;
    technologies: string[];
    startDate: string;
    endDate: string;
    current: boolean;
    url?: string;
    githubUrl?: string;
    achievements: string[];
  }>;
  certifications: Array<{
    id: string;
    name: string;
    issuer: string;
    dateObtained: string;
    expiryDate?: string;
    credentialId?: string;
    verificationUrl?: string;
  }>;
  skills: {
    technical: string[];
    soft: string[];
    languages: string[];
  };
  targetRole?: string;
  targetIndustry?: string;
}

const initialResumeData: ResumeData = {
  personalInfo: {
    fullName: '',
    email: '',
    phone: '',
    location: '',
    linkedIn: '',
    website: '',
    summary: '',
  },
  experience: [],
  education: [],
  projects: [],
  certifications: [],
  skills: {
    technical: [],
    soft: [],
    languages: [],
  },
};

export default function App() {
  const [resumeData, setResumeData] = useState<ResumeData>(initialResumeData);
  const [selectedTemplate, setSelectedTemplate] = useState<'modern' | 'classic' | 'creative'>('modern');
  const [activeStep, setActiveStep] = useState<'personal' | 'experience' | 'education' | 'projects' | 'certifications' | 'skills' | 'preview'>('personal');
  const [showAIAssistant, setShowAIAssistant] = useState(false);
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [showResumeManager, setShowResumeManager] = useState(false);
  const [atsScore, setAtsScore] = useState<number>(85);
  const [currentResumeId, setCurrentResumeId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isExportingPDF, setIsExportingPDF] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [user, setUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);

  // Get the singleton Supabase client with cross-browser compatibility
  const supabase = getSupabaseClient();

  // Check for existing session on mount with cross-browser support
  useEffect(() => {
    let mounted = true;
    
    const checkSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (mounted && session?.access_token && !error) {
          setUser(session.user);
          setAccessToken(session.access_token);
          await loadUserResumes();
        }
      } catch (error) {
        console.log('Session check failed:', error);
      }
    };

    checkSession();

    // Set up auth state change listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (event, session) => {
      if (!mounted) return;
      
      if (event === 'SIGNED_IN' && session) {
        setUser(session.user);
        setAccessToken(session.access_token);
        await loadUserResumes();
      } else if (event === 'SIGNED_OUT') {
        setUser(null);
        setAccessToken('');
        setCurrentResumeId(null);
        setResumeData(initialResumeData);
      }
    });

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, []);

  // Load local data if not authenticated with cross-browser localStorage support
  useEffect(() => {
    if (!user && typeof window !== 'undefined') {
      try {
        const savedData = localStorage.getItem('resumeData');
        if (savedData) {
          const parsedData = JSON.parse(savedData);
          // Ensure new fields exist for backward compatibility
          setResumeData({
            ...initialResumeData,
            ...parsedData,
            projects: parsedData.projects || [],
            certifications: parsedData.certifications || [],
          });
        }
        
        const savedTemplate = localStorage.getItem('selectedTemplate');
        if (savedTemplate && ['modern', 'classic', 'creative'].includes(savedTemplate)) {
          setSelectedTemplate(savedTemplate as 'modern' | 'classic' | 'creative');
        }
      } catch (error) {
        console.log('Error loading local data:', error);
      }
    }
  }, [user]);

  // Auto-save for authenticated users with debouncing
  useEffect(() => {
    if (user && resumeData.personalInfo.fullName) {
      const timeoutId = setTimeout(() => {
        saveResume();
      }, 2000); // Auto-save after 2 seconds of inactivity

      return () => clearTimeout(timeoutId);
    } else if (!user && typeof window !== 'undefined') {
      // Save to localStorage for non-authenticated users
      try {
        localStorage.setItem('resumeData', JSON.stringify(resumeData));
      } catch (error) {
        console.log('Error saving to localStorage:', error);
      }
    }
  }, [resumeData, user]);

  // Save template selection with cross-browser support
  useEffect(() => {
    if (!user && typeof window !== 'undefined') {
      try {
        localStorage.setItem('selectedTemplate', selectedTemplate);
      } catch (error) {
        console.log('Error saving template to localStorage:', error);
      }
    }
  }, [selectedTemplate, user]);

  const handleSignIn = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      const { data: { session }, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        throw new Error(error.message);
      }

      if (session?.access_token) {
        setUser(session.user);
        setAccessToken(session.access_token);
        setShowAuthModal(false);
        
        // Load user's resumes
        await loadUserResumes();
      }
    } catch (error: any) {
      console.log('Sign in error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignUp = async (email: string, password: string, fullName: string) => {
    setIsLoading(true);
    try {
      // First try direct Supabase signup
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            full_name: fullName,
          }
        }
      });

      if (error) {
        // Fallback to custom function if direct signup fails
        const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/auth/signup`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ email, password, fullName }),
        });

        const result = await response.json();
        if (!response.ok) {
          throw new Error(result.error || 'Signup failed');
        }
      }

      // Auto sign in after successful signup
      await handleSignIn(email, password);
    } catch (error: any) {
      console.log('Sign up error:', error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      // The auth state change listener will handle cleanup
    } catch (error) {
      console.log('Sign out error:', error);
    }
  };

  const loadUserResumes = async () => {
    if (!accessToken) return;

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/resumes`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        },
      });

      const result = await response.json();
      if (response.ok && result.resumes.length > 0) {
        // Load the most recent resume
        const latestResume = result.resumes.sort((a: any, b: any) => 
          new Date(b.lastModified).getTime() - new Date(a.lastModified).getTime()
        )[0];
        
        // Ensure backward compatibility with new fields
        const enhancedResume = {
          ...initialResumeData,
          ...latestResume,
          projects: latestResume.projects || [],
          certifications: latestResume.certifications || [],
        };
        
        setResumeData(enhancedResume);
        setCurrentResumeId(latestResume.id);
      }
    } catch (error) {
      console.log('Error loading resumes:', error);
    }
  };

  const saveResume = async () => {
    if (!user || !accessToken || isSaving) return;

    setIsSaving(true);
    try {
      const url = currentResumeId 
        ? `https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/resumes/${currentResumeId}`
        : `https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/resumes`;
      
      const method = currentResumeId ? 'PUT' : 'POST';

      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify(resumeData),
      });

      const result = await response.json();
      if (response.ok && !currentResumeId) {
        setCurrentResumeId(result.resumeId);
      }
    } catch (error) {
      console.log('Error saving resume:', error);
    } finally {
      setIsSaving(false);
    }
  };

  const updateResumeData = (section: keyof ResumeData, data: any) => {
    setResumeData(prev => ({
      ...prev,
      [section]: data,
    }));
  };

  const updateATSScore = async () => {
    if (!accessToken) return;

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-6a9e14f0/ai/ats-check`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ resumeData }),
      });

      const result = await response.json();
      if (response.ok) {
        setAtsScore(result.score);
      }
    } catch (error) {
      console.log('Error updating ATS score:', error);
    }
  };

  const handleQuickPDFExport = async () => {
    if (!resumeData.personalInfo.fullName) {
      alert('Please fill in your personal information before exporting.');
      return;
    }

    setIsExportingPDF(true);
    setExportProgress(0);

    try {
      await exportToPDF({
        resumeData,
        template: selectedTemplate,
        onProgress: setExportProgress,
      });
    } catch (error) {
      console.error('Quick PDF export error:', error);
      alert('Failed to export PDF. Please try again.');
    } finally {
      setTimeout(() => {
        setIsExportingPDF(false);
        setExportProgress(0);
      }, 1000);
    }
  };

  useEffect(() => {
    if (user && resumeData.personalInfo.fullName) {
      updateATSScore();
    }
  }, [resumeData, user]);

  const steps = [
    { id: 'personal', label: 'Personal Info', completed: !!resumeData.personalInfo.fullName },
    { id: 'experience', label: 'Experience', completed: resumeData.experience.length > 0 },
    { id: 'education', label: 'Education', completed: resumeData.education.length > 0 },
    { id: 'projects', label: 'Projects', completed: resumeData.projects.length > 0 },
    { id: 'certifications', label: 'Certifications', completed: resumeData.certifications.length > 0 },
    { id: 'skills', label: 'Skills', completed: resumeData.skills.technical.length > 0 },
    { id: 'preview', label: 'Preview & Export', completed: false },
  ];

  const currentStepIndex = steps.findIndex(step => step.id === activeStep);
  const completedSteps = steps.filter(step => step.completed).length;
  const progressPercentage = (completedSteps / (steps.length - 1)) * 100;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <Sparkles className="h-6 w-6 text-primary" />
                <h1 className="text-xl font-medium">AI Resume Builder</h1>
              </div>
              {!user && (
                <Badge variant="secondary" className="flex items-center gap-1">
                  <Shield className="h-3 w-3" />
                  Data stays local
                </Badge>
              )}
              {user && (
                <Badge variant="outline" className="flex items-center gap-1">
                  <Cloud className="h-3 w-3" />
                  {isSaving ? 'Saving...' : 'Cloud sync enabled'}
                </Badge>
              )}
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-sm text-muted-foreground">
                ATS Score: <span className={`font-medium ${atsScore >= 80 ? 'text-green-600' : atsScore >= 60 ? 'text-yellow-600' : 'text-red-600'}`}>
                  {atsScore}%
                </span>
              </div>

              {/* Quick PDF Export Button */}
              {resumeData.personalInfo.fullName && (
                <div className="relative">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleQuickPDFExport}
                    disabled={isExportingPDF}
                    className="flex items-center gap-2"
                  >
                    {isExportingPDF ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-current" />
                        {exportProgress}%
                      </>
                    ) : (
                      <>
                        <FileDown className="h-4 w-4" />
                        Export PDF
                      </>
                    )}
                  </Button>
                  {isExportingPDF && exportProgress > 0 && (
                    <div className="absolute top-full left-0 right-0 mt-1">
                      <Progress value={exportProgress} className="h-1" />
                    </div>
                  )}
                </div>
              )}
              
              {user ? (
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setShowResumeManager(true)}
                  >
                    My Resumes
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={saveResume}
                    disabled={isSaving}
                    className="flex items-center gap-1"
                  >
                    <Save className="h-4 w-4" />
                    {isSaving ? 'Saving...' : 'Save'}
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleSignOut}
                    className="flex items-center gap-1"
                  >
                    <User className="h-4 w-4" />
                    Sign Out
                  </Button>
                </div>
              ) : (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowAuthModal(true)}
                  className="flex items-center gap-1"
                >
                  <User className="h-4 w-4" />
                  Sign In / Sign Up
                </Button>
              )}
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowAIAssistant(!showAIAssistant)}
                className="flex items-center gap-2"
              >
                <Sparkles className="h-4 w-4" />
                AI Assistant
              </Button>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="mt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm text-muted-foreground">
                Step {currentStepIndex + 1} of {steps.length}: {steps[currentStepIndex]?.label}
              </span>
              <span className="text-sm text-muted-foreground">
                {Math.round(progressPercentage)}% Complete
              </span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div 
                className="bg-primary h-2 rounded-full transition-all duration-300"
                style={{ width: `${progressPercentage}%` }}
              />
            </div>
          </div>
          
          {/* Step Navigation */}
          <div className="flex gap-2 mt-4 flex-wrap">
            {steps.map((step, index) => (
              <Button
                key={step.id}
                variant={activeStep === step.id ? "default" : step.completed ? "secondary" : "outline"}
                size="sm"
                onClick={() => setActiveStep(step.id as any)}
                className="flex items-center gap-2"
              >
                {step.completed && <div className="w-2 h-2 bg-green-500 rounded-full" />}
                {step.label}
              </Button>
            ))}
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Panel - Forms */}
          <div className="space-y-6">
            {activeStep === 'personal' && (
              <PersonalInfoForm
                data={resumeData.personalInfo}
                onChange={(data) => updateResumeData('personalInfo', data)}
                onNext={() => setActiveStep('experience')}
                isAuthenticated={!!user}
                accessToken={accessToken}
              />
            )}
            
            {activeStep === 'experience' && (
              <ExperienceForm
                data={resumeData.experience}
                onChange={(data) => updateResumeData('experience', data)}
                onNext={() => setActiveStep('education')}
                onPrev={() => setActiveStep('personal')}
                isAuthenticated={!!user}
                accessToken={accessToken}
              />
            )}
            
            {activeStep === 'education' && (
              <EducationForm
                data={resumeData.education}
                onChange={(data) => updateResumeData('education', data)}
                onNext={() => setActiveStep('projects')}
                onPrev={() => setActiveStep('experience')}
              />
            )}
            
            {activeStep === 'projects' && (
              <ProjectsForm
                data={resumeData.projects}
                onChange={(data) => updateResumeData('projects', data)}
                onNext={() => setActiveStep('certifications')}
                onPrev={() => setActiveStep('education')}
              />
            )}
            
            {activeStep === 'certifications' && (
              <CertificationsForm
                data={resumeData.certifications}
                onChange={(data) => updateResumeData('certifications', data)}
                onNext={() => setActiveStep('skills')}
                onPrev={() => setActiveStep('projects')}
              />
            )}
            
            {activeStep === 'skills' && (
              <SkillsForm
                data={resumeData.skills}
                onChange={(data) => updateResumeData('skills', data)}
                onNext={() => setActiveStep('preview')}
                onPrev={() => setActiveStep('certifications')}
              />
            )}
            
            {activeStep === 'preview' && (
              <div className="space-y-6">
                <TemplateSelector
                  selectedTemplate={selectedTemplate}
                  onTemplateChange={setSelectedTemplate}
                />
                <ExportOptions 
                  resumeData={resumeData} 
                  template={selectedTemplate}
                  isAuthenticated={!!user}
                  accessToken={accessToken}
                />
              </div>
            )}
            
            {/* AI Assistant Panel */}
            {showAIAssistant && (
              <AIAssistant
                resumeData={resumeData}
                onSuggestionApply={(suggestion) => {
                  console.log('Applying AI suggestion:', suggestion);
                }}
                onClose={() => setShowAIAssistant(false)}
                isAuthenticated={!!user}
                accessToken={accessToken}
              />
            )}
          </div>

          {/* Right Panel - Preview */}
          <div className="lg:sticky lg:top-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Eye className="h-5 w-5" />
                  Live Preview
                </CardTitle>
                <div className="flex items-center gap-2">
                  <Badge variant="outline">{selectedTemplate} template</Badge>
                  {resumeData.personalInfo.fullName && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={handleQuickPDFExport}
                      disabled={isExportingPDF}
                      className="flex items-center gap-1"
                    >
                      <Download className="h-3 w-3" />
                      {isExportingPDF ? `${exportProgress}%` : 'PDF'}
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <ResumePreview
                  data={resumeData}
                  template={selectedTemplate}
                  isPDFMode={false}
                />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Modals */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onSignIn={handleSignIn}
          onSignUp={handleSignUp}
          isLoading={isLoading}
        />
      )}

      {showResumeManager && user && (
        <ResumeManager
          onClose={() => setShowResumeManager(false)}
          onResumeSelect={(resume) => {
            // Ensure backward compatibility with new fields
            const enhancedResume = {
              ...initialResumeData,
              ...resume,
              projects: resume.projects || [],
              certifications: resume.certifications || [],
            };
            setResumeData(enhancedResume);
            setCurrentResumeId(resume.id);
            setShowResumeManager(false);
          }}
          accessToken={accessToken}
        />
      )}
    </div>
  );
}